﻿namespace WatchDocks
{
    partial class ExpertViewMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExpertViewMode));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label77 = new System.Windows.Forms.Label();
            this.n4 = new System.Windows.Forms.Label();
            this.n1 = new System.Windows.Forms.Label();
            this.n7 = new System.Windows.Forms.Label();
            this.n5 = new System.Windows.Forms.Label();
            this.n8 = new System.Windows.Forms.Label();
            this.n2 = new System.Windows.Forms.Label();
            this.n6 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.n9 = new System.Windows.Forms.Label();
            this.n3 = new System.Windows.Forms.Label();
            this.g4 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.g3 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.g1 = new System.Windows.Forms.Label();
            this.e4 = new System.Windows.Forms.Label();
            this.g9 = new System.Windows.Forms.Label();
            this.e1 = new System.Windows.Forms.Label();
            this.g7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.g6 = new System.Windows.Forms.Label();
            this.e7 = new System.Windows.Forms.Label();
            this.g5 = new System.Windows.Forms.Label();
            this.c1 = new System.Windows.Forms.Label();
            this.g2 = new System.Windows.Forms.Label();
            this.e5 = new System.Windows.Forms.Label();
            this.g8 = new System.Windows.Forms.Label();
            this.a5 = new System.Windows.Forms.Label();
            this.e8 = new System.Windows.Forms.Label();
            this.c5 = new System.Windows.Forms.Label();
            this.e2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label61 = new System.Windows.Forms.Label();
            this.f4 = new System.Windows.Forms.Label();
            this.f3 = new System.Windows.Forms.Label();
            this.f1 = new System.Windows.Forms.Label();
            this.f9 = new System.Windows.Forms.Label();
            this.f7 = new System.Windows.Forms.Label();
            this.f6 = new System.Windows.Forms.Label();
            this.f5 = new System.Windows.Forms.Label();
            this.f2 = new System.Windows.Forms.Label();
            this.f8 = new System.Windows.Forms.Label();
            this.e6 = new System.Windows.Forms.Label();
            this.c2 = new System.Windows.Forms.Label();
            this.e9 = new System.Windows.Forms.Label();
            this.a4 = new System.Windows.Forms.Label();
            this.e3 = new System.Windows.Forms.Label();
            this.c4 = new System.Windows.Forms.Label();
            this.c3 = new System.Windows.Forms.Label();
            this.c9 = new System.Windows.Forms.Label();
            this.a9 = new System.Windows.Forms.Label();
            this.c6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.b1 = new System.Windows.Forms.Label();
            this.b5 = new System.Windows.Forms.Label();
            this.b2 = new System.Windows.Forms.Label();
            this.b4 = new System.Windows.Forms.Label();
            this.b3 = new System.Windows.Forms.Label();
            this.b9 = new System.Windows.Forms.Label();
            this.b6 = new System.Windows.Forms.Label();
            this.b8 = new System.Windows.Forms.Label();
            this.b7 = new System.Windows.Forms.Label();
            this.c8 = new System.Windows.Forms.Label();
            this.a8 = new System.Windows.Forms.Label();
            this.c7 = new System.Windows.Forms.Label();
            this.a7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.h4 = new System.Windows.Forms.Label();
            this.h8 = new System.Windows.Forms.Label();
            this.h3 = new System.Windows.Forms.Label();
            this.h2 = new System.Windows.Forms.Label();
            this.h1 = new System.Windows.Forms.Label();
            this.h5 = new System.Windows.Forms.Label();
            this.h9 = new System.Windows.Forms.Label();
            this.h6 = new System.Windows.Forms.Label();
            this.h7 = new System.Windows.Forms.Label();
            this.a6 = new System.Windows.Forms.Label();
            this.a3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.d4 = new System.Windows.Forms.Label();
            this.d1 = new System.Windows.Forms.Label();
            this.d7 = new System.Windows.Forms.Label();
            this.d5 = new System.Windows.Forms.Label();
            this.d8 = new System.Windows.Forms.Label();
            this.d2 = new System.Windows.Forms.Label();
            this.d6 = new System.Windows.Forms.Label();
            this.d9 = new System.Windows.Forms.Label();
            this.d3 = new System.Windows.Forms.Label();
            this.a2 = new System.Windows.Forms.Label();
            this.a1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.t5 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label67 = new System.Windows.Forms.Label();
            this.m4 = new System.Windows.Forms.Label();
            this.m3 = new System.Windows.Forms.Label();
            this.m1 = new System.Windows.Forms.Label();
            this.m9 = new System.Windows.Forms.Label();
            this.m7 = new System.Windows.Forms.Label();
            this.m6 = new System.Windows.Forms.Label();
            this.m5 = new System.Windows.Forms.Label();
            this.m2 = new System.Windows.Forms.Label();
            this.m8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.setBar = new MetroFramework.Controls.MetroTrackBar();
            this.panel22 = new System.Windows.Forms.Panel();
            this.t9 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label177 = new System.Windows.Forms.Label();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label77);
            this.panel1.Controls.Add(this.n4);
            this.panel1.Controls.Add(this.n1);
            this.panel1.Controls.Add(this.n7);
            this.panel1.Controls.Add(this.n5);
            this.panel1.Controls.Add(this.n8);
            this.panel1.Controls.Add(this.n2);
            this.panel1.Controls.Add(this.n6);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.n9);
            this.panel1.Controls.Add(this.n3);
            this.panel1.Controls.Add(this.g4);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.g3);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.g1);
            this.panel1.Controls.Add(this.e4);
            this.panel1.Controls.Add(this.g9);
            this.panel1.Controls.Add(this.e1);
            this.panel1.Controls.Add(this.g7);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.g6);
            this.panel1.Controls.Add(this.e7);
            this.panel1.Controls.Add(this.g5);
            this.panel1.Controls.Add(this.c1);
            this.panel1.Controls.Add(this.g2);
            this.panel1.Controls.Add(this.e5);
            this.panel1.Controls.Add(this.g8);
            this.panel1.Controls.Add(this.a5);
            this.panel1.Controls.Add(this.e8);
            this.panel1.Controls.Add(this.c5);
            this.panel1.Controls.Add(this.e2);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.e6);
            this.panel1.Controls.Add(this.c2);
            this.panel1.Controls.Add(this.e9);
            this.panel1.Controls.Add(this.a4);
            this.panel1.Controls.Add(this.e3);
            this.panel1.Controls.Add(this.c4);
            this.panel1.Controls.Add(this.c3);
            this.panel1.Controls.Add(this.c9);
            this.panel1.Controls.Add(this.a9);
            this.panel1.Controls.Add(this.c6);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.c8);
            this.panel1.Controls.Add(this.a8);
            this.panel1.Controls.Add(this.c7);
            this.panel1.Controls.Add(this.a7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.a6);
            this.panel1.Controls.Add(this.a3);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.a2);
            this.panel1.Controls.Add(this.a1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Location = new System.Drawing.Point(23, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1357, 522);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.Transparent;
            this.label77.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label77.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label77.Location = new System.Drawing.Point(8, 307);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(53, 12);
            this.label77.TabIndex = 140;
            this.label77.Text = "Litecoin";
            // 
            // n4
            // 
            this.n4.BackColor = System.Drawing.Color.Transparent;
            this.n4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n4.Location = new System.Drawing.Point(541, 307);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(120, 12);
            this.n4.TabIndex = 138;
            this.n4.Text = "-";
            this.n4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n1
            // 
            this.n1.BackColor = System.Drawing.Color.Transparent;
            this.n1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n1.Location = new System.Drawing.Point(124, 307);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(120, 12);
            this.n1.TabIndex = 131;
            this.n1.Text = "-";
            this.n1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n7
            // 
            this.n7.BackColor = System.Drawing.Color.Transparent;
            this.n7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n7.Location = new System.Drawing.Point(952, 307);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(120, 12);
            this.n7.TabIndex = 135;
            this.n7.Text = "-";
            this.n7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n5
            // 
            this.n5.BackColor = System.Drawing.Color.Transparent;
            this.n5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n5.Location = new System.Drawing.Point(680, 307);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(120, 12);
            this.n5.TabIndex = 139;
            this.n5.Text = "-";
            this.n5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n8
            // 
            this.n8.BackColor = System.Drawing.Color.Transparent;
            this.n8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n8.Location = new System.Drawing.Point(1086, 307);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(120, 12);
            this.n8.TabIndex = 136;
            this.n8.Text = "-";
            this.n8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n2
            // 
            this.n2.BackColor = System.Drawing.Color.Transparent;
            this.n2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n2.Location = new System.Drawing.Point(263, 307);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(120, 12);
            this.n2.TabIndex = 132;
            this.n2.Text = "-";
            this.n2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n6
            // 
            this.n6.BackColor = System.Drawing.Color.Transparent;
            this.n6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n6.Location = new System.Drawing.Point(817, 307);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(120, 12);
            this.n6.TabIndex = 134;
            this.n6.Text = "-";
            this.n6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(8, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 80;
            this.label6.Text = "Qtum";
            // 
            // n9
            // 
            this.n9.BackColor = System.Drawing.Color.Transparent;
            this.n9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n9.Location = new System.Drawing.Point(1225, 307);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(120, 12);
            this.n9.TabIndex = 137;
            this.n9.Text = "-";
            this.n9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // n3
            // 
            this.n3.BackColor = System.Drawing.Color.Transparent;
            this.n3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.n3.Location = new System.Drawing.Point(402, 307);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(120, 12);
            this.n3.TabIndex = 133;
            this.n3.Text = "-";
            this.n3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g4
            // 
            this.g4.BackColor = System.Drawing.Color.Transparent;
            this.g4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g4.Location = new System.Drawing.Point(541, 242);
            this.g4.Name = "g4";
            this.g4.Size = new System.Drawing.Size(120, 12);
            this.g4.TabIndex = 78;
            this.g4.Text = "-";
            this.g4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label51.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label51.Location = new System.Drawing.Point(8, 176);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(77, 12);
            this.label51.TabIndex = 60;
            this.label51.Text = "Bitcoin Cash";
            // 
            // g3
            // 
            this.g3.BackColor = System.Drawing.Color.Transparent;
            this.g3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g3.Location = new System.Drawing.Point(402, 242);
            this.g3.Name = "g3";
            this.g3.Size = new System.Drawing.Size(120, 12);
            this.g3.TabIndex = 73;
            this.g3.Text = "-";
            this.g3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label31.Location = new System.Drawing.Point(8, 110);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 12);
            this.label31.TabIndex = 40;
            this.label31.Text = "Ripple";
            // 
            // g1
            // 
            this.g1.BackColor = System.Drawing.Color.Transparent;
            this.g1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g1.Location = new System.Drawing.Point(124, 242);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(120, 12);
            this.g1.TabIndex = 71;
            this.g1.Text = "-";
            this.g1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e4
            // 
            this.e4.BackColor = System.Drawing.Color.Transparent;
            this.e4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e4.Location = new System.Drawing.Point(541, 176);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(120, 12);
            this.e4.TabIndex = 58;
            this.e4.Text = "-";
            this.e4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g9
            // 
            this.g9.BackColor = System.Drawing.Color.Transparent;
            this.g9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g9.Location = new System.Drawing.Point(1225, 242);
            this.g9.Name = "g9";
            this.g9.Size = new System.Drawing.Size(120, 12);
            this.g9.TabIndex = 77;
            this.g9.Text = "-";
            this.g9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e1
            // 
            this.e1.BackColor = System.Drawing.Color.Transparent;
            this.e1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e1.Location = new System.Drawing.Point(124, 176);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(120, 12);
            this.e1.TabIndex = 51;
            this.e1.Text = "-";
            this.e1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g7
            // 
            this.g7.BackColor = System.Drawing.Color.Transparent;
            this.g7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g7.Location = new System.Drawing.Point(952, 242);
            this.g7.Name = "g7";
            this.g7.Size = new System.Drawing.Size(120, 12);
            this.g7.TabIndex = 75;
            this.g7.Text = "-";
            this.g7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Location = new System.Drawing.Point(8, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "Bitcoin";
            // 
            // g6
            // 
            this.g6.BackColor = System.Drawing.Color.Transparent;
            this.g6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g6.Location = new System.Drawing.Point(817, 242);
            this.g6.Name = "g6";
            this.g6.Size = new System.Drawing.Size(120, 12);
            this.g6.TabIndex = 74;
            this.g6.Text = "-";
            this.g6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e7
            // 
            this.e7.BackColor = System.Drawing.Color.Transparent;
            this.e7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e7.Location = new System.Drawing.Point(952, 176);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(120, 12);
            this.e7.TabIndex = 55;
            this.e7.Text = "-";
            this.e7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g5
            // 
            this.g5.BackColor = System.Drawing.Color.Transparent;
            this.g5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g5.Location = new System.Drawing.Point(680, 242);
            this.g5.Name = "g5";
            this.g5.Size = new System.Drawing.Size(120, 12);
            this.g5.TabIndex = 79;
            this.g5.Text = "-";
            this.g5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c1
            // 
            this.c1.BackColor = System.Drawing.Color.Transparent;
            this.c1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c1.Location = new System.Drawing.Point(124, 110);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(120, 12);
            this.c1.TabIndex = 31;
            this.c1.Text = "-";
            this.c1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g2
            // 
            this.g2.BackColor = System.Drawing.Color.Transparent;
            this.g2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g2.Location = new System.Drawing.Point(263, 242);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(120, 12);
            this.g2.TabIndex = 72;
            this.g2.Text = "-";
            this.g2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e5
            // 
            this.e5.BackColor = System.Drawing.Color.Transparent;
            this.e5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e5.Location = new System.Drawing.Point(680, 176);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(120, 12);
            this.e5.TabIndex = 59;
            this.e5.Text = "-";
            this.e5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // g8
            // 
            this.g8.BackColor = System.Drawing.Color.Transparent;
            this.g8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.g8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.g8.Location = new System.Drawing.Point(1086, 242);
            this.g8.Name = "g8";
            this.g8.Size = new System.Drawing.Size(120, 12);
            this.g8.TabIndex = 76;
            this.g8.Text = "-";
            this.g8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a5
            // 
            this.a5.BackColor = System.Drawing.Color.Transparent;
            this.a5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a5.Location = new System.Drawing.Point(679, 45);
            this.a5.Name = "a5";
            this.a5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a5.Size = new System.Drawing.Size(120, 12);
            this.a5.TabIndex = 19;
            this.a5.Text = "-";
            this.a5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.a5.Click += new System.EventHandler(this.a5_Click);
            // 
            // e8
            // 
            this.e8.BackColor = System.Drawing.Color.Transparent;
            this.e8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e8.Location = new System.Drawing.Point(1086, 176);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(120, 12);
            this.e8.TabIndex = 56;
            this.e8.Text = "-";
            this.e8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c5
            // 
            this.c5.BackColor = System.Drawing.Color.Transparent;
            this.c5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c5.Location = new System.Drawing.Point(680, 110);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(120, 12);
            this.c5.TabIndex = 39;
            this.c5.Text = "-";
            this.c5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e2
            // 
            this.e2.BackColor = System.Drawing.Color.Transparent;
            this.e2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e2.Location = new System.Drawing.Point(263, 176);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(120, 12);
            this.e2.TabIndex = 52;
            this.e2.Text = "-";
            this.e2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label61);
            this.panel4.Controls.Add(this.f4);
            this.panel4.Controls.Add(this.f3);
            this.panel4.Controls.Add(this.f1);
            this.panel4.Controls.Add(this.f9);
            this.panel4.Controls.Add(this.f7);
            this.panel4.Controls.Add(this.f6);
            this.panel4.Controls.Add(this.f5);
            this.panel4.Controls.Add(this.f2);
            this.panel4.Controls.Add(this.f8);
            this.panel4.Location = new System.Drawing.Point(-1, 199);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1357, 34);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label61.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label61.Location = new System.Drawing.Point(8, 10);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(101, 12);
            this.label61.TabIndex = 70;
            this.label61.Text = "Ethereum Classic";
            // 
            // f4
            // 
            this.f4.BackColor = System.Drawing.Color.Transparent;
            this.f4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f4.Location = new System.Drawing.Point(541, 10);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(120, 12);
            this.f4.TabIndex = 68;
            this.f4.Text = "-";
            this.f4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f3
            // 
            this.f3.BackColor = System.Drawing.Color.Transparent;
            this.f3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f3.Location = new System.Drawing.Point(402, 10);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(120, 12);
            this.f3.TabIndex = 63;
            this.f3.Text = "-";
            this.f3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f1
            // 
            this.f1.BackColor = System.Drawing.Color.Transparent;
            this.f1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f1.Location = new System.Drawing.Point(124, 10);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(120, 12);
            this.f1.TabIndex = 61;
            this.f1.Text = "-";
            this.f1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f9
            // 
            this.f9.BackColor = System.Drawing.Color.Transparent;
            this.f9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f9.Location = new System.Drawing.Point(1225, 10);
            this.f9.Name = "f9";
            this.f9.Size = new System.Drawing.Size(120, 12);
            this.f9.TabIndex = 67;
            this.f9.Text = "-";
            this.f9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f7
            // 
            this.f7.BackColor = System.Drawing.Color.Transparent;
            this.f7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f7.Location = new System.Drawing.Point(952, 10);
            this.f7.Name = "f7";
            this.f7.Size = new System.Drawing.Size(120, 12);
            this.f7.TabIndex = 65;
            this.f7.Text = "-";
            this.f7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f6
            // 
            this.f6.BackColor = System.Drawing.Color.Transparent;
            this.f6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f6.Location = new System.Drawing.Point(817, 10);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(120, 12);
            this.f6.TabIndex = 64;
            this.f6.Text = "-";
            this.f6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f5
            // 
            this.f5.BackColor = System.Drawing.Color.Transparent;
            this.f5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f5.Location = new System.Drawing.Point(680, 10);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(120, 12);
            this.f5.TabIndex = 69;
            this.f5.Text = "-";
            this.f5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f2
            // 
            this.f2.BackColor = System.Drawing.Color.Transparent;
            this.f2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f2.Location = new System.Drawing.Point(263, 10);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(120, 12);
            this.f2.TabIndex = 62;
            this.f2.Text = "-";
            this.f2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // f8
            // 
            this.f8.BackColor = System.Drawing.Color.Transparent;
            this.f8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.f8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.f8.Location = new System.Drawing.Point(1086, 10);
            this.f8.Name = "f8";
            this.f8.Size = new System.Drawing.Size(120, 12);
            this.f8.TabIndex = 66;
            this.f8.Text = "-";
            this.f8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e6
            // 
            this.e6.BackColor = System.Drawing.Color.Transparent;
            this.e6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e6.Location = new System.Drawing.Point(817, 176);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(120, 12);
            this.e6.TabIndex = 54;
            this.e6.Text = "-";
            this.e6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.Color.Transparent;
            this.c2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c2.Location = new System.Drawing.Point(263, 110);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(120, 12);
            this.c2.TabIndex = 32;
            this.c2.Text = "-";
            this.c2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e9
            // 
            this.e9.BackColor = System.Drawing.Color.Transparent;
            this.e9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e9.Location = new System.Drawing.Point(1225, 176);
            this.e9.Name = "e9";
            this.e9.Size = new System.Drawing.Size(120, 12);
            this.e9.TabIndex = 57;
            this.e9.Text = "-";
            this.e9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a4
            // 
            this.a4.BackColor = System.Drawing.Color.Transparent;
            this.a4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a4.Location = new System.Drawing.Point(540, 45);
            this.a4.Name = "a4";
            this.a4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a4.Size = new System.Drawing.Size(120, 12);
            this.a4.TabIndex = 18;
            this.a4.Text = "-";
            this.a4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // e3
            // 
            this.e3.BackColor = System.Drawing.Color.Transparent;
            this.e3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.e3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.e3.Location = new System.Drawing.Point(402, 176);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(120, 12);
            this.e3.TabIndex = 53;
            this.e3.Text = "-";
            this.e3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c4
            // 
            this.c4.BackColor = System.Drawing.Color.Transparent;
            this.c4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c4.Location = new System.Drawing.Point(541, 110);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(120, 12);
            this.c4.TabIndex = 38;
            this.c4.Text = "-";
            this.c4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c3
            // 
            this.c3.BackColor = System.Drawing.Color.Transparent;
            this.c3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c3.Location = new System.Drawing.Point(402, 110);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(120, 12);
            this.c3.TabIndex = 33;
            this.c3.Text = "-";
            this.c3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c9
            // 
            this.c9.BackColor = System.Drawing.Color.Transparent;
            this.c9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c9.Location = new System.Drawing.Point(1225, 110);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(120, 12);
            this.c9.TabIndex = 37;
            this.c9.Text = "-";
            this.c9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a9
            // 
            this.a9.BackColor = System.Drawing.Color.Transparent;
            this.a9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a9.Location = new System.Drawing.Point(1224, 45);
            this.a9.Name = "a9";
            this.a9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a9.Size = new System.Drawing.Size(120, 12);
            this.a9.TabIndex = 17;
            this.a9.Text = "-";
            this.a9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c6
            // 
            this.c6.BackColor = System.Drawing.Color.Transparent;
            this.c6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c6.Location = new System.Drawing.Point(817, 110);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(120, 12);
            this.c6.TabIndex = 34;
            this.c6.Text = "-";
            this.c6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.b1);
            this.panel3.Controls.Add(this.b5);
            this.panel3.Controls.Add(this.b2);
            this.panel3.Controls.Add(this.b4);
            this.panel3.Controls.Add(this.b3);
            this.panel3.Controls.Add(this.b9);
            this.panel3.Controls.Add(this.b6);
            this.panel3.Controls.Add(this.b8);
            this.panel3.Controls.Add(this.b7);
            this.panel3.Location = new System.Drawing.Point(-1, 67);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1357, 34);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Location = new System.Drawing.Point(8, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 30;
            this.label16.Text = "Ethereum";
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Transparent;
            this.b1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b1.Location = new System.Drawing.Point(123, 11);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(120, 12);
            this.b1.TabIndex = 21;
            this.b1.Text = "-";
            this.b1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Transparent;
            this.b5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b5.Location = new System.Drawing.Point(679, 11);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(120, 12);
            this.b5.TabIndex = 29;
            this.b5.Text = "-";
            this.b5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Transparent;
            this.b2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b2.Location = new System.Drawing.Point(262, 11);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(120, 12);
            this.b2.TabIndex = 22;
            this.b2.Text = "-";
            this.b2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Transparent;
            this.b4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b4.Location = new System.Drawing.Point(540, 11);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(120, 12);
            this.b4.TabIndex = 28;
            this.b4.Text = "-";
            this.b4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Transparent;
            this.b3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b3.Location = new System.Drawing.Point(401, 11);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(120, 12);
            this.b3.TabIndex = 23;
            this.b3.Text = "-";
            this.b3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.Transparent;
            this.b9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b9.Location = new System.Drawing.Point(1224, 11);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(120, 12);
            this.b9.TabIndex = 27;
            this.b9.Text = "-";
            this.b9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Transparent;
            this.b6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b6.Location = new System.Drawing.Point(816, 11);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(120, 12);
            this.b6.TabIndex = 24;
            this.b6.Text = "-";
            this.b6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.Transparent;
            this.b8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b8.Location = new System.Drawing.Point(1085, 11);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(120, 12);
            this.b8.TabIndex = 26;
            this.b8.Text = "-";
            this.b8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.Transparent;
            this.b7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.b7.Location = new System.Drawing.Point(951, 11);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(120, 12);
            this.b7.TabIndex = 25;
            this.b7.Text = "-";
            this.b7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // c8
            // 
            this.c8.BackColor = System.Drawing.Color.Transparent;
            this.c8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c8.Location = new System.Drawing.Point(1086, 110);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(120, 12);
            this.c8.TabIndex = 36;
            this.c8.Text = "-";
            this.c8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a8
            // 
            this.a8.BackColor = System.Drawing.Color.Transparent;
            this.a8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a8.Location = new System.Drawing.Point(1085, 45);
            this.a8.Name = "a8";
            this.a8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a8.Size = new System.Drawing.Size(120, 12);
            this.a8.TabIndex = 16;
            this.a8.Text = "-";
            this.a8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.a8.Click += new System.EventHandler(this.a8_Click);
            // 
            // c7
            // 
            this.c7.BackColor = System.Drawing.Color.Transparent;
            this.c7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.c7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.c7.Location = new System.Drawing.Point(952, 110);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(120, 12);
            this.c7.TabIndex = 35;
            this.c7.Text = "-";
            this.c7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a7
            // 
            this.a7.BackColor = System.Drawing.Color.Transparent;
            this.a7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a7.Location = new System.Drawing.Point(951, 45);
            this.a7.Name = "a7";
            this.a7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a7.Size = new System.Drawing.Size(120, 12);
            this.a7.TabIndex = 15;
            this.a7.Text = "-";
            this.a7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.h4);
            this.panel6.Controls.Add(this.h8);
            this.panel6.Controls.Add(this.h3);
            this.panel6.Controls.Add(this.h2);
            this.panel6.Controls.Add(this.h1);
            this.panel6.Controls.Add(this.h5);
            this.panel6.Controls.Add(this.h9);
            this.panel6.Controls.Add(this.h6);
            this.panel6.Controls.Add(this.h7);
            this.panel6.Location = new System.Drawing.Point(-1, 262);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1357, 34);
            this.panel6.TabIndex = 4;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18.Location = new System.Drawing.Point(8, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 90;
            this.label18.Text = "Dash";
            // 
            // h4
            // 
            this.h4.BackColor = System.Drawing.Color.Transparent;
            this.h4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h4.Location = new System.Drawing.Point(541, 10);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(120, 12);
            this.h4.TabIndex = 88;
            this.h4.Text = "-";
            this.h4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h8
            // 
            this.h8.BackColor = System.Drawing.Color.Transparent;
            this.h8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h8.Location = new System.Drawing.Point(1086, 10);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(120, 12);
            this.h8.TabIndex = 86;
            this.h8.Text = "-";
            this.h8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h3
            // 
            this.h3.BackColor = System.Drawing.Color.Transparent;
            this.h3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h3.Location = new System.Drawing.Point(402, 10);
            this.h3.Name = "h3";
            this.h3.Size = new System.Drawing.Size(120, 12);
            this.h3.TabIndex = 83;
            this.h3.Text = "-";
            this.h3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h2
            // 
            this.h2.BackColor = System.Drawing.Color.Transparent;
            this.h2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h2.Location = new System.Drawing.Point(263, 10);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(120, 12);
            this.h2.TabIndex = 82;
            this.h2.Text = "-";
            this.h2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h1
            // 
            this.h1.BackColor = System.Drawing.Color.Transparent;
            this.h1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h1.Location = new System.Drawing.Point(124, 10);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(120, 12);
            this.h1.TabIndex = 81;
            this.h1.Text = "-";
            this.h1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h5
            // 
            this.h5.BackColor = System.Drawing.Color.Transparent;
            this.h5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h5.Location = new System.Drawing.Point(680, 10);
            this.h5.Name = "h5";
            this.h5.Size = new System.Drawing.Size(120, 12);
            this.h5.TabIndex = 89;
            this.h5.Text = "-";
            this.h5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h9
            // 
            this.h9.BackColor = System.Drawing.Color.Transparent;
            this.h9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h9.Location = new System.Drawing.Point(1225, 10);
            this.h9.Name = "h9";
            this.h9.Size = new System.Drawing.Size(120, 12);
            this.h9.TabIndex = 87;
            this.h9.Text = "-";
            this.h9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h6
            // 
            this.h6.BackColor = System.Drawing.Color.Transparent;
            this.h6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h6.Location = new System.Drawing.Point(817, 10);
            this.h6.Name = "h6";
            this.h6.Size = new System.Drawing.Size(120, 12);
            this.h6.TabIndex = 84;
            this.h6.Text = "-";
            this.h6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // h7
            // 
            this.h7.BackColor = System.Drawing.Color.Transparent;
            this.h7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.h7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.h7.Location = new System.Drawing.Point(952, 10);
            this.h7.Name = "h7";
            this.h7.Size = new System.Drawing.Size(120, 12);
            this.h7.TabIndex = 85;
            this.h7.Text = "-";
            this.h7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a6
            // 
            this.a6.BackColor = System.Drawing.Color.Transparent;
            this.a6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a6.Location = new System.Drawing.Point(816, 45);
            this.a6.Name = "a6";
            this.a6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a6.Size = new System.Drawing.Size(120, 12);
            this.a6.TabIndex = 14;
            this.a6.Text = "-";
            this.a6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a3
            // 
            this.a3.BackColor = System.Drawing.Color.Transparent;
            this.a3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a3.Location = new System.Drawing.Point(401, 45);
            this.a3.Name = "a3";
            this.a3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a3.Size = new System.Drawing.Size(120, 12);
            this.a3.TabIndex = 13;
            this.a3.Text = "-";
            this.a3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label41);
            this.panel5.Controls.Add(this.d4);
            this.panel5.Controls.Add(this.d1);
            this.panel5.Controls.Add(this.d7);
            this.panel5.Controls.Add(this.d5);
            this.panel5.Controls.Add(this.d8);
            this.panel5.Controls.Add(this.d2);
            this.panel5.Controls.Add(this.d6);
            this.panel5.Controls.Add(this.d9);
            this.panel5.Controls.Add(this.d3);
            this.panel5.Location = new System.Drawing.Point(-1, 131);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1357, 34);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label41.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label41.Location = new System.Drawing.Point(8, 10);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(23, 12);
            this.label41.TabIndex = 50;
            this.label41.Text = "EOS";
            // 
            // d4
            // 
            this.d4.BackColor = System.Drawing.Color.Transparent;
            this.d4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d4.Location = new System.Drawing.Point(540, 10);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(120, 12);
            this.d4.TabIndex = 48;
            this.d4.Text = "-";
            this.d4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d1
            // 
            this.d1.BackColor = System.Drawing.Color.Transparent;
            this.d1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d1.Location = new System.Drawing.Point(123, 10);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(120, 12);
            this.d1.TabIndex = 41;
            this.d1.Text = "-";
            this.d1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d7
            // 
            this.d7.BackColor = System.Drawing.Color.Transparent;
            this.d7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d7.Location = new System.Drawing.Point(951, 10);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(120, 12);
            this.d7.TabIndex = 45;
            this.d7.Text = "-";
            this.d7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d5
            // 
            this.d5.BackColor = System.Drawing.Color.Transparent;
            this.d5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d5.Location = new System.Drawing.Point(679, 10);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(120, 12);
            this.d5.TabIndex = 49;
            this.d5.Text = "-";
            this.d5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d8
            // 
            this.d8.BackColor = System.Drawing.Color.Transparent;
            this.d8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d8.Location = new System.Drawing.Point(1085, 10);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(120, 12);
            this.d8.TabIndex = 46;
            this.d8.Text = "-";
            this.d8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d2
            // 
            this.d2.BackColor = System.Drawing.Color.Transparent;
            this.d2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d2.Location = new System.Drawing.Point(262, 10);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(120, 12);
            this.d2.TabIndex = 42;
            this.d2.Text = "-";
            this.d2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d6
            // 
            this.d6.BackColor = System.Drawing.Color.Transparent;
            this.d6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d6.Location = new System.Drawing.Point(816, 10);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(120, 12);
            this.d6.TabIndex = 44;
            this.d6.Text = "-";
            this.d6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d9
            // 
            this.d9.BackColor = System.Drawing.Color.Transparent;
            this.d9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d9.Location = new System.Drawing.Point(1224, 10);
            this.d9.Name = "d9";
            this.d9.Size = new System.Drawing.Size(120, 12);
            this.d9.TabIndex = 47;
            this.d9.Text = "-";
            this.d9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // d3
            // 
            this.d3.BackColor = System.Drawing.Color.Transparent;
            this.d3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.d3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.d3.Location = new System.Drawing.Point(401, 10);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(120, 12);
            this.d3.TabIndex = 43;
            this.d3.Text = "-";
            this.d3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a2
            // 
            this.a2.BackColor = System.Drawing.Color.Transparent;
            this.a2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a2.Location = new System.Drawing.Point(262, 45);
            this.a2.Name = "a2";
            this.a2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a2.Size = new System.Drawing.Size(120, 12);
            this.a2.TabIndex = 12;
            this.a2.Text = "-";
            this.a2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a1
            // 
            this.a1.BackColor = System.Drawing.Color.Transparent;
            this.a1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.a1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.a1.Location = new System.Drawing.Point(123, 45);
            this.a1.Name = "a1";
            this.a1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a1.Size = new System.Drawing.Size(120, 12);
            this.a1.TabIndex = 11;
            this.a1.Text = "-";
            this.a1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.t5);
            this.panel2.Location = new System.Drawing.Point(-1, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1357, 34);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(729, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Change Rate";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(584, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "Change Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(1280, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Sell Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(1147, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Buy Price";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label27.Location = new System.Drawing.Point(989, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(83, 12);
            this.label27.TabIndex = 6;
            this.label27.Text = "Closing Price";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label26.Location = new System.Drawing.Point(854, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 12);
            this.label26.TabIndex = 5;
            this.label26.Text = "Opening Price";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label25.Location = new System.Drawing.Point(439, 10);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(83, 12);
            this.label25.TabIndex = 4;
            this.label25.Text = "Average Price";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label24.Location = new System.Drawing.Point(300, 10);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 12);
            this.label24.TabIndex = 3;
            this.label24.Text = "Maximum Price";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(161, 10);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "Minimum Price";
            // 
            // t5
            // 
            this.t5.AutoSize = true;
            this.t5.BackColor = System.Drawing.Color.Transparent;
            this.t5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t5.Location = new System.Drawing.Point(8, 10);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(29, 12);
            this.t5.TabIndex = 1;
            this.t5.Text = "Name";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label67);
            this.panel8.Controls.Add(this.m4);
            this.panel8.Controls.Add(this.m3);
            this.panel8.Controls.Add(this.m1);
            this.panel8.Controls.Add(this.m9);
            this.panel8.Controls.Add(this.m7);
            this.panel8.Controls.Add(this.m6);
            this.panel8.Controls.Add(this.m5);
            this.panel8.Controls.Add(this.m2);
            this.panel8.Controls.Add(this.m8);
            this.panel8.Location = new System.Drawing.Point(-1, 329);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1357, 34);
            this.panel8.TabIndex = 6;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Transparent;
            this.label67.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label67.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label67.Location = new System.Drawing.Point(8, 10);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(83, 12);
            this.label67.TabIndex = 130;
            this.label67.Text = "Stellar Lumen";
            // 
            // m4
            // 
            this.m4.BackColor = System.Drawing.Color.Transparent;
            this.m4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m4.Location = new System.Drawing.Point(541, 10);
            this.m4.Name = "m4";
            this.m4.Size = new System.Drawing.Size(120, 12);
            this.m4.TabIndex = 128;
            this.m4.Text = "-";
            this.m4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m3
            // 
            this.m3.BackColor = System.Drawing.Color.Transparent;
            this.m3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m3.Location = new System.Drawing.Point(402, 10);
            this.m3.Name = "m3";
            this.m3.Size = new System.Drawing.Size(120, 12);
            this.m3.TabIndex = 123;
            this.m3.Text = "-";
            this.m3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m1
            // 
            this.m1.BackColor = System.Drawing.Color.Transparent;
            this.m1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m1.Location = new System.Drawing.Point(124, 10);
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(120, 12);
            this.m1.TabIndex = 121;
            this.m1.Text = "-";
            this.m1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m9
            // 
            this.m9.BackColor = System.Drawing.Color.Transparent;
            this.m9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m9.Location = new System.Drawing.Point(1225, 10);
            this.m9.Name = "m9";
            this.m9.Size = new System.Drawing.Size(120, 12);
            this.m9.TabIndex = 127;
            this.m9.Text = "-";
            this.m9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m7
            // 
            this.m7.BackColor = System.Drawing.Color.Transparent;
            this.m7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m7.Location = new System.Drawing.Point(952, 10);
            this.m7.Name = "m7";
            this.m7.Size = new System.Drawing.Size(120, 12);
            this.m7.TabIndex = 125;
            this.m7.Text = "-";
            this.m7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m6
            // 
            this.m6.BackColor = System.Drawing.Color.Transparent;
            this.m6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m6.Location = new System.Drawing.Point(817, 10);
            this.m6.Name = "m6";
            this.m6.Size = new System.Drawing.Size(120, 12);
            this.m6.TabIndex = 124;
            this.m6.Text = "-";
            this.m6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m5
            // 
            this.m5.BackColor = System.Drawing.Color.Transparent;
            this.m5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m5.Location = new System.Drawing.Point(680, 10);
            this.m5.Name = "m5";
            this.m5.Size = new System.Drawing.Size(120, 12);
            this.m5.TabIndex = 129;
            this.m5.Text = "-";
            this.m5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m2
            // 
            this.m2.BackColor = System.Drawing.Color.Transparent;
            this.m2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m2.Location = new System.Drawing.Point(263, 10);
            this.m2.Name = "m2";
            this.m2.Size = new System.Drawing.Size(120, 12);
            this.m2.TabIndex = 122;
            this.m2.Text = "-";
            this.m2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // m8
            // 
            this.m8.BackColor = System.Drawing.Color.Transparent;
            this.m8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.m8.Location = new System.Drawing.Point(1086, 10);
            this.m8.Name = "m8";
            this.m8.Size = new System.Drawing.Size(120, 12);
            this.m8.TabIndex = 126;
            this.m8.Text = "-";
            this.m8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(968, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "Opacity";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // setBar
            // 
            this.setBar.BackColor = System.Drawing.Color.Transparent;
            this.setBar.Location = new System.Drawing.Point(1020, 28);
            this.setBar.Minimum = 10;
            this.setBar.Name = "setBar";
            this.setBar.Size = new System.Drawing.Size(186, 25);
            this.setBar.Style = MetroFramework.MetroColorStyle.Black;
            this.setBar.TabIndex = 3;
            this.setBar.Text = "metroTrackBar1";
            this.setBar.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.setBar.Value = 100;
            this.setBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.setBar_Scroll);
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.t9);
            this.panel22.Location = new System.Drawing.Point(678, 27);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(169, 25);
            this.panel22.TabIndex = 53;
            this.panel22.Visible = false;
            // 
            // t9
            // 
            this.t9.AutoSize = true;
            this.t9.BackColor = System.Drawing.Color.Transparent;
            this.t9.Dock = System.Windows.Forms.DockStyle.Left;
            this.t9.Font = new System.Drawing.Font("굴림체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t9.Location = new System.Drawing.Point(0, 0);
            this.t9.Name = "t9";
            this.t9.Size = new System.Drawing.Size(15, 15);
            this.t9.TabIndex = 0;
            this.t9.Text = "-";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.label177);
            this.panel14.Location = new System.Drawing.Point(853, 27);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(97, 25);
            this.panel14.TabIndex = 54;
            this.panel14.Visible = false;
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.BackColor = System.Drawing.Color.Transparent;
            this.label177.Dock = System.Windows.Forms.DockStyle.Left;
            this.label177.Font = new System.Drawing.Font("굴림체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label177.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label177.Location = new System.Drawing.Point(0, 0);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(15, 15);
            this.label177.TabIndex = 0;
            this.label177.Text = "-";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Black;
            this.metroButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton1.BackgroundImage")));
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.ForeColor = System.Drawing.Color.White;
            this.metroButton1.Location = new System.Drawing.Point(1219, 27);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(161, 25);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton1.TabIndex = 59;
            this.metroButton1.TabStop = false;
            this.metroButton1.Text = "EXIT";
            this.metroButton1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(582, 417);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 33);
            this.label12.TabIndex = 65;
            this.label12.Text = "X Monitor II";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ExpertViewMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1400, 600);
            this.ControlBox = false;
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.setBar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel14);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ExpertViewMode";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Text = "Detail View Window";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.ExoertViewMode_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Label t5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label5;
        private MetroFramework.Controls.MetroTrackBar setBar;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label a5;
        public System.Windows.Forms.Label a4;
        public System.Windows.Forms.Label a9;
        public System.Windows.Forms.Label a8;
        public System.Windows.Forms.Label a7;
        public System.Windows.Forms.Label a6;
        public System.Windows.Forms.Label a3;
        public System.Windows.Forms.Label a2;
        public System.Windows.Forms.Label a1;
        public System.Windows.Forms.Label label51;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label e4;
        public System.Windows.Forms.Label e1;
        public System.Windows.Forms.Label e7;
        public System.Windows.Forms.Label c1;
        public System.Windows.Forms.Label e5;
        public System.Windows.Forms.Label e8;
        public System.Windows.Forms.Label c5;
        public System.Windows.Forms.Label e2;
        public System.Windows.Forms.Label label61;
        public System.Windows.Forms.Label f4;
        public System.Windows.Forms.Label f3;
        public System.Windows.Forms.Label f1;
        public System.Windows.Forms.Label f9;
        public System.Windows.Forms.Label f7;
        public System.Windows.Forms.Label f6;
        public System.Windows.Forms.Label f5;
        public System.Windows.Forms.Label f2;
        public System.Windows.Forms.Label f8;
        public System.Windows.Forms.Label e6;
        public System.Windows.Forms.Label c2;
        public System.Windows.Forms.Label e9;
        public System.Windows.Forms.Label e3;
        public System.Windows.Forms.Label c4;
        public System.Windows.Forms.Label c3;
        public System.Windows.Forms.Label c9;
        public System.Windows.Forms.Label c6;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label b1;
        public System.Windows.Forms.Label b5;
        public System.Windows.Forms.Label b2;
        public System.Windows.Forms.Label b4;
        public System.Windows.Forms.Label b3;
        public System.Windows.Forms.Label b9;
        public System.Windows.Forms.Label b6;
        public System.Windows.Forms.Label b8;
        public System.Windows.Forms.Label b7;
        public System.Windows.Forms.Label c8;
        public System.Windows.Forms.Label c7;
        public System.Windows.Forms.Label label41;
        public System.Windows.Forms.Label d4;
        public System.Windows.Forms.Label d1;
        public System.Windows.Forms.Label d7;
        public System.Windows.Forms.Label d5;
        public System.Windows.Forms.Label d8;
        public System.Windows.Forms.Label d2;
        public System.Windows.Forms.Label d6;
        public System.Windows.Forms.Label d9;
        public System.Windows.Forms.Label d3;
        private System.Windows.Forms.Panel panel22;
        public System.Windows.Forms.Label t9;
        public System.Windows.Forms.Label label77;
        public System.Windows.Forms.Label n4;
        public System.Windows.Forms.Label n1;
        public System.Windows.Forms.Label n7;
        public System.Windows.Forms.Label n5;
        public System.Windows.Forms.Label n8;
        public System.Windows.Forms.Label n2;
        public System.Windows.Forms.Label n6;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label n9;
        public System.Windows.Forms.Label n3;
        public System.Windows.Forms.Label g4;
        public System.Windows.Forms.Label g3;
        public System.Windows.Forms.Label g1;
        public System.Windows.Forms.Label g9;
        public System.Windows.Forms.Label g7;
        public System.Windows.Forms.Label g6;
        public System.Windows.Forms.Label g5;
        public System.Windows.Forms.Label g2;
        public System.Windows.Forms.Label g8;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label h4;
        public System.Windows.Forms.Label h8;
        public System.Windows.Forms.Label h3;
        public System.Windows.Forms.Label h2;
        public System.Windows.Forms.Label h1;
        public System.Windows.Forms.Label h5;
        public System.Windows.Forms.Label h9;
        public System.Windows.Forms.Label h6;
        public System.Windows.Forms.Label h7;
        public System.Windows.Forms.Label label67;
        public System.Windows.Forms.Label m4;
        public System.Windows.Forms.Label m1;
        public System.Windows.Forms.Label m7;
        public System.Windows.Forms.Label m5;
        public System.Windows.Forms.Label m8;
        public System.Windows.Forms.Label m2;
        public System.Windows.Forms.Label m6;
        public System.Windows.Forms.Label m9;
        public System.Windows.Forms.Label m3;
        private System.Windows.Forms.Panel panel14;
        public System.Windows.Forms.Label label177;
        public MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label label12;
    }
}