﻿namespace Planet
{
    partial class setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(setting));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.b6 = new System.Windows.Forms.PictureBox();
            this.c6 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.b5 = new System.Windows.Forms.PictureBox();
            this.c5 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.b4 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.c4 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.b3 = new System.Windows.Forms.PictureBox();
            this.c3 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.b2 = new System.Windows.Forms.PictureBox();
            this.c2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.SetName = new System.Windows.Forms.Label();
            this.valuePanel01 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.t12 = new System.Windows.Forms.TextBox();
            this.bt1 = new MetroFramework.Controls.MetroButton();
            this.bt2 = new MetroFramework.Controls.MetroButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.SetName2 = new System.Windows.Forms.Label();
            this.t10 = new System.Windows.Forms.TextBox();
            this.t9 = new System.Windows.Forms.TextBox();
            this.t8 = new System.Windows.Forms.TextBox();
            this.t7 = new System.Windows.Forms.TextBox();
            this.t6 = new System.Windows.Forms.TextBox();
            this.t5 = new System.Windows.Forms.TextBox();
            this.t4 = new System.Windows.Forms.TextBox();
            this.t3 = new System.Windows.Forms.TextBox();
            this.t2 = new System.Windows.Forms.TextBox();
            this.t1 = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.t11 = new System.Windows.Forms.Label();
            this.main01 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c6)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c5)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c4)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c3)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.valuePanel01.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel14.SuspendLayout();
            this.main01.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(188, 410);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.b6);
            this.panel5.Controls.Add(this.c6);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 217);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(188, 38);
            this.panel5.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(25, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 15);
            this.label10.TabIndex = 12;
            this.label10.Text = "Bitcoin Cash";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Transparent;
            this.b6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b6.BackgroundImage")));
            this.b6.Dock = System.Windows.Forms.DockStyle.Top;
            this.b6.Location = new System.Drawing.Point(19, 0);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(169, 38);
            this.b6.TabIndex = 2;
            this.b6.TabStop = false;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // c6
            // 
            this.c6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c6.Dock = System.Windows.Forms.DockStyle.Left;
            this.c6.Location = new System.Drawing.Point(0, 0);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(19, 38);
            this.c6.TabIndex = 2;
            this.c6.TabStop = false;
            this.c6.Visible = false;
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.Controls.Add(this.label9);
            this.panel11.Controls.Add(this.b5);
            this.panel11.Controls.Add(this.c5);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 179);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(188, 38);
            this.panel11.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(25, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "EOS";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Transparent;
            this.b5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b5.BackgroundImage")));
            this.b5.Dock = System.Windows.Forms.DockStyle.Top;
            this.b5.Location = new System.Drawing.Point(19, 0);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(169, 38);
            this.b5.TabIndex = 2;
            this.b5.TabStop = false;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // c5
            // 
            this.c5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c5.Dock = System.Windows.Forms.DockStyle.Left;
            this.c5.Location = new System.Drawing.Point(0, 0);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(19, 38);
            this.c5.TabIndex = 2;
            this.c5.TabStop = false;
            this.c5.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.b4);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.c4);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 141);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(188, 38);
            this.panel7.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(25, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Ripple";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Transparent;
            this.b4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b4.BackgroundImage")));
            this.b4.Dock = System.Windows.Forms.DockStyle.Top;
            this.b4.Location = new System.Drawing.Point(19, 0);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(169, 38);
            this.b4.TabIndex = 2;
            this.b4.TabStop = false;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(25, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Button 01";
            // 
            // c4
            // 
            this.c4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c4.Dock = System.Windows.Forms.DockStyle.Left;
            this.c4.Location = new System.Drawing.Point(0, 0);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(19, 38);
            this.c4.TabIndex = 2;
            this.c4.TabStop = false;
            this.c4.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.b3);
            this.panel4.Controls.Add(this.c3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 103);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(188, 38);
            this.panel4.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(26, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Ethereum";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Transparent;
            this.b3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b3.BackgroundImage")));
            this.b3.Dock = System.Windows.Forms.DockStyle.Top;
            this.b3.Location = new System.Drawing.Point(19, 0);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(169, 38);
            this.b3.TabIndex = 2;
            this.b3.TabStop = false;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // c3
            // 
            this.c3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c3.Dock = System.Windows.Forms.DockStyle.Left;
            this.c3.Location = new System.Drawing.Point(0, 0);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(19, 38);
            this.c3.TabIndex = 2;
            this.c3.TabStop = false;
            this.c3.Visible = false;
            // 
            // panel8
            // 
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.b2);
            this.panel8.Controls.Add(this.c2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 65);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(188, 38);
            this.panel8.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(25, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Bitcoin";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Transparent;
            this.b2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b2.BackgroundImage")));
            this.b2.Dock = System.Windows.Forms.DockStyle.Top;
            this.b2.Location = new System.Drawing.Point(19, 0);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(169, 38);
            this.b2.TabIndex = 2;
            this.b2.TabStop = false;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c2.Dock = System.Windows.Forms.DockStyle.Left;
            this.c2.Location = new System.Drawing.Point(0, 0);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(19, 38);
            this.c2.TabIndex = 2;
            this.c2.TabStop = false;
            this.c2.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(188, 65);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Setting";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.SetName);
            this.panel13.Location = new System.Drawing.Point(16, 172);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(117, 21);
            this.panel13.TabIndex = 20;
            // 
            // SetName
            // 
            this.SetName.BackColor = System.Drawing.Color.Transparent;
            this.SetName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SetName.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SetName.ForeColor = System.Drawing.Color.Red;
            this.SetName.Location = new System.Drawing.Point(0, 0);
            this.SetName.Name = "SetName";
            this.SetName.Size = new System.Drawing.Size(115, 19);
            this.SetName.TabIndex = 0;
            this.SetName.Text = "-";
            this.SetName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // valuePanel01
            // 
            this.valuePanel01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.valuePanel01.Controls.Add(this.panel3);
            this.valuePanel01.Controls.Add(this.panel40);
            this.valuePanel01.Controls.Add(this.panel39);
            this.valuePanel01.Controls.Add(this.panel25);
            this.valuePanel01.Controls.Add(this.panel19);
            this.valuePanel01.Controls.Add(this.panel29);
            this.valuePanel01.Controls.Add(this.panel26);
            this.valuePanel01.Controls.Add(this.panel31);
            this.valuePanel01.Controls.Add(this.panel32);
            this.valuePanel01.Controls.Add(this.panel33);
            this.valuePanel01.Controls.Add(this.panel16);
            this.valuePanel01.Controls.Add(this.panel34);
            this.valuePanel01.Controls.Add(this.panel18);
            this.valuePanel01.Controls.Add(this.panel35);
            this.valuePanel01.Controls.Add(this.panel12);
            this.valuePanel01.Controls.Add(this.panel30);
            this.valuePanel01.Controls.Add(this.panel27);
            this.valuePanel01.Controls.Add(this.textBox3);
            this.valuePanel01.Controls.Add(this.panel22);
            this.valuePanel01.Controls.Add(this.t12);
            this.valuePanel01.Controls.Add(this.bt1);
            this.valuePanel01.Controls.Add(this.bt2);
            this.valuePanel01.Controls.Add(this.panel15);
            this.valuePanel01.Controls.Add(this.t10);
            this.valuePanel01.Controls.Add(this.t9);
            this.valuePanel01.Controls.Add(this.t8);
            this.valuePanel01.Controls.Add(this.t7);
            this.valuePanel01.Controls.Add(this.t6);
            this.valuePanel01.Controls.Add(this.t5);
            this.valuePanel01.Controls.Add(this.t4);
            this.valuePanel01.Controls.Add(this.t3);
            this.valuePanel01.Controls.Add(this.t2);
            this.valuePanel01.Controls.Add(this.t1);
            this.valuePanel01.Controls.Add(this.panel13);
            this.valuePanel01.Controls.Add(this.panel14);
            this.valuePanel01.Controls.Add(this.panel17);
            this.valuePanel01.Location = new System.Drawing.Point(200, 63);
            this.valuePanel01.Name = "valuePanel01";
            this.valuePanel01.Size = new System.Drawing.Size(752, 321);
            this.valuePanel01.TabIndex = 1;
            this.valuePanel01.Paint += new System.Windows.Forms.PaintEventHandler(this.panel12_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(139, 199);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(598, 11);
            this.panel3.TabIndex = 71;
            // 
            // panel40
            // 
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.label33);
            this.panel40.Location = new System.Drawing.Point(304, 216);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(433, 21);
            this.panel40.TabIndex = 21;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Location = new System.Drawing.Point(0, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(431, 19);
            this.label33.TabIndex = 0;
            this.label33.Text = "-";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel39
            // 
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.Controls.Add(this.label32);
            this.panel39.Location = new System.Drawing.Point(139, 216);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(160, 21);
            this.panel39.TabIndex = 35;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(0, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(158, 19);
            this.label32.TabIndex = 0;
            this.label32.Text = "Latest Save Date";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Location = new System.Drawing.Point(16, 199);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(117, 38);
            this.panel25.TabIndex = 70;
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.label16);
            this.panel19.Location = new System.Drawing.Point(139, 21);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(160, 21);
            this.panel19.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(158, 19);
            this.label16.TabIndex = 0;
            this.label16.Text = "Max Opening Price";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.label22);
            this.panel29.Location = new System.Drawing.Point(441, 21);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(160, 21);
            this.panel29.TabIndex = 28;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(0, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(158, 19);
            this.label22.TabIndex = 0;
            this.label22.Text = "Min Opening Pirce";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.label18);
            this.panel26.Location = new System.Drawing.Point(139, 48);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(160, 21);
            this.panel26.TabIndex = 33;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(158, 19);
            this.label18.TabIndex = 0;
            this.label18.Text = "Max Closing Price";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.label23);
            this.panel31.Location = new System.Drawing.Point(441, 48);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(160, 21);
            this.panel31.TabIndex = 27;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(0, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(158, 19);
            this.label23.TabIndex = 0;
            this.label23.Text = "Min Closing Price";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel32
            // 
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.label24);
            this.panel32.Location = new System.Drawing.Point(139, 74);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(160, 21);
            this.panel32.TabIndex = 32;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(0, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(158, 19);
            this.label24.TabIndex = 0;
            this.label24.Text = "Max Average Price";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel33
            // 
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Controls.Add(this.label25);
            this.panel33.Location = new System.Drawing.Point(139, 101);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(160, 21);
            this.panel33.TabIndex = 31;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(0, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(158, 19);
            this.label25.TabIndex = 0;
            this.label25.Text = "Max Maximum Price";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label15);
            this.panel16.Location = new System.Drawing.Point(441, 74);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(160, 21);
            this.panel16.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(158, 19);
            this.label15.TabIndex = 0;
            this.label15.Text = "Min Average Price";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel34
            // 
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.label26);
            this.panel34.Location = new System.Drawing.Point(139, 145);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(160, 21);
            this.panel34.TabIndex = 30;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(0, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(158, 19);
            this.label26.TabIndex = 0;
            this.label26.Text = "Max Minimum Price";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.label21);
            this.panel18.Location = new System.Drawing.Point(441, 101);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(160, 21);
            this.panel18.TabIndex = 25;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(0, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 19);
            this.label21.TabIndex = 0;
            this.label21.Text = "Min Maximum Price";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.label27);
            this.panel35.Location = new System.Drawing.Point(139, 172);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(160, 21);
            this.panel35.TabIndex = 29;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(158, 19);
            this.label27.TabIndex = 0;
            this.label27.Text = "Max Change (%)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label7);
            this.panel12.Location = new System.Drawing.Point(440, 145);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(160, 21);
            this.panel12.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "Min Minimum Price";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Location = new System.Drawing.Point(16, 48);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(117, 118);
            this.panel30.TabIndex = 69;
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.label20);
            this.panel27.Location = new System.Drawing.Point(440, 172);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(160, 21);
            this.panel27.TabIndex = 24;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(0, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(158, 19);
            this.label20.TabIndex = 0;
            this.label20.Text = "Percentage (%)";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.ForeColor = System.Drawing.Color.Lime;
            this.textBox3.Location = new System.Drawing.Point(605, 172);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(131, 21);
            this.textBox3.TabIndex = 73;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Location = new System.Drawing.Point(139, 128);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(598, 11);
            this.panel22.TabIndex = 70;
            // 
            // t12
            // 
            this.t12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t12.Enabled = false;
            this.t12.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t12.ForeColor = System.Drawing.Color.Lime;
            this.t12.Location = new System.Drawing.Point(304, 172);
            this.t12.Name = "t12";
            this.t12.Size = new System.Drawing.Size(130, 21);
            this.t12.TabIndex = 57;
            // 
            // bt1
            // 
            this.bt1.BackColor = System.Drawing.Color.Black;
            this.bt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt1.BackgroundImage")));
            this.bt1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.bt1.ForeColor = System.Drawing.Color.White;
            this.bt1.Location = new System.Drawing.Point(410, 282);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(160, 21);
            this.bt1.TabIndex = 56;
            this.bt1.TabStop = false;
            this.bt1.Text = "Modify";
            this.bt1.UseCustomBackColor = true;
            this.bt1.UseCustomForeColor = true;
            this.bt1.UseSelectable = true;
            this.bt1.UseStyleColors = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt2
            // 
            this.bt2.BackColor = System.Drawing.Color.Black;
            this.bt2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt2.BackgroundImage")));
            this.bt2.Enabled = false;
            this.bt2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.bt2.ForeColor = System.Drawing.Color.White;
            this.bt2.Location = new System.Drawing.Point(576, 282);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(161, 21);
            this.bt2.TabIndex = 35;
            this.bt2.TabStop = false;
            this.bt2.Text = "Save";
            this.bt2.UseCustomBackColor = true;
            this.bt2.UseCustomForeColor = true;
            this.bt2.UseSelectable = true;
            this.bt2.UseStyleColors = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.SetName2);
            this.panel15.Location = new System.Drawing.Point(16, 21);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(117, 21);
            this.panel15.TabIndex = 21;
            // 
            // SetName2
            // 
            this.SetName2.BackColor = System.Drawing.Color.Transparent;
            this.SetName2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SetName2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SetName2.ForeColor = System.Drawing.Color.Red;
            this.SetName2.Location = new System.Drawing.Point(0, 0);
            this.SetName2.Name = "SetName2";
            this.SetName2.Size = new System.Drawing.Size(115, 19);
            this.SetName2.TabIndex = 0;
            this.SetName2.Text = "-";
            this.SetName2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // t10
            // 
            this.t10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t10.Enabled = false;
            this.t10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t10.ForeColor = System.Drawing.Color.Lime;
            this.t10.Location = new System.Drawing.Point(605, 145);
            this.t10.Name = "t10";
            this.t10.Size = new System.Drawing.Size(131, 21);
            this.t10.TabIndex = 53;
            // 
            // t9
            // 
            this.t9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t9.Enabled = false;
            this.t9.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t9.ForeColor = System.Drawing.Color.Lime;
            this.t9.Location = new System.Drawing.Point(607, 101);
            this.t9.Name = "t9";
            this.t9.Size = new System.Drawing.Size(130, 21);
            this.t9.TabIndex = 52;
            // 
            // t8
            // 
            this.t8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t8.Enabled = false;
            this.t8.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t8.ForeColor = System.Drawing.Color.Lime;
            this.t8.Location = new System.Drawing.Point(607, 74);
            this.t8.Name = "t8";
            this.t8.Size = new System.Drawing.Size(130, 21);
            this.t8.TabIndex = 49;
            // 
            // t7
            // 
            this.t7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t7.Enabled = false;
            this.t7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t7.ForeColor = System.Drawing.Color.Lime;
            this.t7.Location = new System.Drawing.Point(607, 48);
            this.t7.Name = "t7";
            this.t7.Size = new System.Drawing.Size(130, 21);
            this.t7.TabIndex = 48;
            // 
            // t6
            // 
            this.t6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t6.Enabled = false;
            this.t6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t6.ForeColor = System.Drawing.Color.Lime;
            this.t6.Location = new System.Drawing.Point(607, 21);
            this.t6.Name = "t6";
            this.t6.Size = new System.Drawing.Size(130, 21);
            this.t6.TabIndex = 47;
            // 
            // t5
            // 
            this.t5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t5.Enabled = false;
            this.t5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t5.ForeColor = System.Drawing.Color.Lime;
            this.t5.Location = new System.Drawing.Point(304, 145);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(130, 21);
            this.t5.TabIndex = 43;
            // 
            // t4
            // 
            this.t4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t4.Enabled = false;
            this.t4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t4.ForeColor = System.Drawing.Color.Lime;
            this.t4.Location = new System.Drawing.Point(304, 101);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(131, 21);
            this.t4.TabIndex = 41;
            // 
            // t3
            // 
            this.t3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t3.Enabled = false;
            this.t3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t3.ForeColor = System.Drawing.Color.Lime;
            this.t3.Location = new System.Drawing.Point(304, 74);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(131, 21);
            this.t3.TabIndex = 34;
            // 
            // t2
            // 
            this.t2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t2.Enabled = false;
            this.t2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t2.ForeColor = System.Drawing.Color.Lime;
            this.t2.Location = new System.Drawing.Point(304, 48);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(131, 21);
            this.t2.TabIndex = 33;
            // 
            // t1
            // 
            this.t1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t1.Enabled = false;
            this.t1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t1.ForeColor = System.Drawing.Color.Lime;
            this.t1.Location = new System.Drawing.Point(304, 21);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(131, 21);
            this.t1.TabIndex = 32;
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.label14);
            this.panel17.Location = new System.Drawing.Point(410, 255);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(160, 21);
            this.panel17.TabIndex = 23;
            this.panel17.Visible = false;
            this.panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.panel17_Paint);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(158, 19);
            this.label14.TabIndex = 0;
            this.label14.Text = "Criteria Price";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.t11);
            this.panel14.Enabled = false;
            this.panel14.Location = new System.Drawing.Point(576, 256);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(161, 20);
            this.panel14.TabIndex = 22;
            this.panel14.Visible = false;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // t11
            // 
            this.t11.BackColor = System.Drawing.Color.Transparent;
            this.t11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.t11.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t11.ForeColor = System.Drawing.Color.White;
            this.t11.Location = new System.Drawing.Point(0, 0);
            this.t11.Name = "t11";
            this.t11.Size = new System.Drawing.Size(159, 18);
            this.t11.TabIndex = 0;
            this.t11.Text = "-";
            this.t11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // main01
            // 
            this.main01.Controls.Add(this.label17);
            this.main01.Location = new System.Drawing.Point(200, 63);
            this.main01.Name = "main01";
            this.main01.Size = new System.Drawing.Size(752, 321);
            this.main01.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Silver;
            this.label17.Location = new System.Drawing.Point(214, 138);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(325, 33);
            this.label17.TabIndex = 59;
            this.label17.Text = "X Monitor Alert Setting";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 400);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.main01);
            this.Controls.Add(this.valuePanel01);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(965, 400);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(965, 400);
            this.Name = "setting";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Text = "Setting";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.setting_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c6)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c5)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c4)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c3)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.valuePanel01.ResumeLayout(false);
            this.valuePanel01.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.main01.ResumeLayout(false);
            this.main01.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox b6;
        private System.Windows.Forms.PictureBox c6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.PictureBox b5;
        private System.Windows.Forms.PictureBox c5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox b4;
        private System.Windows.Forms.PictureBox c4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox b3;
        private System.Windows.Forms.PictureBox c3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox b2;
        private System.Windows.Forms.PictureBox c2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel valuePanel01;
        private MetroFramework.Controls.MetroButton bt1;
        private MetroFramework.Controls.MetroButton bt2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel main01;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.Panel panel13;
        public System.Windows.Forms.TextBox t3;
        public System.Windows.Forms.TextBox t2;
        public System.Windows.Forms.TextBox t1;
        public System.Windows.Forms.TextBox t5;
        public System.Windows.Forms.TextBox t4;
        public System.Windows.Forms.Panel panel15;
        public System.Windows.Forms.TextBox t10;
        public System.Windows.Forms.TextBox t9;
        public System.Windows.Forms.TextBox t8;
        public System.Windows.Forms.TextBox t7;
        public System.Windows.Forms.TextBox t6;
        public System.Windows.Forms.TextBox t12;
        public System.Windows.Forms.Panel panel14;
        public System.Windows.Forms.Label SetName;
        public System.Windows.Forms.Label SetName2;
        public System.Windows.Forms.Label t11;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel25;
        public System.Windows.Forms.Panel panel40;
        public System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox textBox3;
    }
}