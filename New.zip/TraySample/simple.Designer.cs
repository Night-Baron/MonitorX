﻿namespace Planet
{
    partial class simple
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(simple));
            this.label10 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.N01 = new System.Windows.Forms.Label();
            this.setBar = new MetroFramework.Controls.MetroTrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.N02 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.N03 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.N04 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.N05 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.N06 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.N07 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.e1 = new MetroFramework.Controls.MetroButton();
            this.e2 = new MetroFramework.Controls.MetroButton();
            this.e3 = new MetroFramework.Controls.MetroButton();
            this.e4 = new MetroFramework.Controls.MetroButton();
            this.e5 = new MetroFramework.Controls.MetroButton();
            this.e6 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.panel7.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label10.Location = new System.Drawing.Point(8, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 12);
            this.label10.TabIndex = 29;
            this.label10.Text = "Cryptocurrency";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.N01);
            this.panel7.Location = new System.Drawing.Point(10, 43);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(115, 19);
            this.panel7.TabIndex = 30;
            // 
            // N01
            // 
            this.N01.AutoSize = true;
            this.N01.BackColor = System.Drawing.Color.Transparent;
            this.N01.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N01.ForeColor = System.Drawing.Color.Lime;
            this.N01.Location = new System.Drawing.Point(2, 3);
            this.N01.Name = "N01";
            this.N01.Size = new System.Drawing.Size(10, 11);
            this.N01.TabIndex = 0;
            this.N01.Text = "-";
            // 
            // setBar
            // 
            this.setBar.BackColor = System.Drawing.Color.Transparent;
            this.setBar.Location = new System.Drawing.Point(704, 4);
            this.setBar.Minimum = 10;
            this.setBar.Name = "setBar";
            this.setBar.Size = new System.Drawing.Size(161, 23);
            this.setBar.Style = MetroFramework.MetroColorStyle.Black;
            this.setBar.TabIndex = 1;
            this.setBar.Text = "metroTrackBar1";
            this.setBar.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.setBar.Value = 100;
            this.setBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.setBar_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(651, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Opacity";
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.N02);
            this.panel18.Location = new System.Drawing.Point(131, 43);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(115, 19);
            this.panel18.TabIndex = 23;
            // 
            // N02
            // 
            this.N02.AutoSize = true;
            this.N02.BackColor = System.Drawing.Color.Transparent;
            this.N02.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N02.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.N02.Location = new System.Drawing.Point(2, 3);
            this.N02.Name = "N02";
            this.N02.Size = new System.Drawing.Size(10, 11);
            this.N02.TabIndex = 0;
            this.N02.Text = "-";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.N03);
            this.panel2.Location = new System.Drawing.Point(249, 43);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(115, 19);
            this.panel2.TabIndex = 24;
            // 
            // N03
            // 
            this.N03.AutoSize = true;
            this.N03.BackColor = System.Drawing.Color.Transparent;
            this.N03.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N03.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.N03.Location = new System.Drawing.Point(2, 3);
            this.N03.Name = "N03";
            this.N03.Size = new System.Drawing.Size(10, 11);
            this.N03.TabIndex = 0;
            this.N03.Text = "-";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.N04);
            this.panel3.Location = new System.Drawing.Point(367, 43);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(115, 19);
            this.panel3.TabIndex = 25;
            // 
            // N04
            // 
            this.N04.AutoSize = true;
            this.N04.BackColor = System.Drawing.Color.Transparent;
            this.N04.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N04.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.N04.Location = new System.Drawing.Point(2, 3);
            this.N04.Name = "N04";
            this.N04.Size = new System.Drawing.Size(10, 11);
            this.N04.TabIndex = 0;
            this.N04.Text = "-";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.N05);
            this.panel4.Location = new System.Drawing.Point(485, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(167, 19);
            this.panel4.TabIndex = 26;
            // 
            // N05
            // 
            this.N05.AutoSize = true;
            this.N05.BackColor = System.Drawing.Color.Transparent;
            this.N05.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N05.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.N05.Location = new System.Drawing.Point(2, 3);
            this.N05.Name = "N05";
            this.N05.Size = new System.Drawing.Size(10, 11);
            this.N05.TabIndex = 0;
            this.N05.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.N06);
            this.panel5.Location = new System.Drawing.Point(655, 43);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 19);
            this.panel5.TabIndex = 27;
            // 
            // N06
            // 
            this.N06.AutoSize = true;
            this.N06.BackColor = System.Drawing.Color.Transparent;
            this.N06.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N06.ForeColor = System.Drawing.SystemColors.Highlight;
            this.N06.Location = new System.Drawing.Point(2, 3);
            this.N06.Name = "N06";
            this.N06.Size = new System.Drawing.Size(10, 11);
            this.N06.TabIndex = 0;
            this.N06.Text = "-";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.N07);
            this.panel6.Location = new System.Drawing.Point(773, 43);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(113, 19);
            this.panel6.TabIndex = 28;
            // 
            // N07
            // 
            this.N07.AutoSize = true;
            this.N07.BackColor = System.Drawing.Color.Transparent;
            this.N07.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N07.ForeColor = System.Drawing.Color.Red;
            this.N07.Location = new System.Drawing.Point(2, 3);
            this.N07.Name = "N07";
            this.N07.Size = new System.Drawing.Size(10, 11);
            this.N07.TabIndex = 0;
            this.N07.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label7.Location = new System.Drawing.Point(771, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "Set Min Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label8.Location = new System.Drawing.Point(129, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "Maximum Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label9.Location = new System.Drawing.Point(247, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "Minimum Price";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label11.Location = new System.Drawing.Point(483, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 12);
            this.label11.TabIndex = 3;
            this.label11.Text = "Time Value";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label13.Location = new System.Drawing.Point(365, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "Average Price";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label15.Location = new System.Drawing.Point(653, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "Set Max Price";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label14.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.label14.Location = new System.Drawing.Point(7, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 15);
            this.label14.TabIndex = 29;
            this.label14.Text = "X Monitor II";
            // 
            // e1
            // 
            this.e1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e1.BackgroundImage")));
            this.e1.Enabled = false;
            this.e1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e1.ForeColor = System.Drawing.Color.White;
            this.e1.Location = new System.Drawing.Point(10, 68);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(74, 15);
            this.e1.Style = MetroFramework.MetroColorStyle.Black;
            this.e1.TabIndex = 37;
            this.e1.TabStop = false;
            this.e1.Text = "Test";
            this.e1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e1.UseCustomBackColor = true;
            this.e1.UseCustomForeColor = true;
            this.e1.UseSelectable = true;
            this.e1.UseStyleColors = true;
            this.e1.Click += new System.EventHandler(this.m2_Click);
            // 
            // e2
            // 
            this.e2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e2.BackgroundImage")));
            this.e2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e2.ForeColor = System.Drawing.Color.White;
            this.e2.Location = new System.Drawing.Point(90, 68);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(74, 15);
            this.e2.Style = MetroFramework.MetroColorStyle.Black;
            this.e2.TabIndex = 38;
            this.e2.TabStop = false;
            this.e2.Text = "Bitcoin";
            this.e2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e2.UseCustomBackColor = true;
            this.e2.UseCustomForeColor = true;
            this.e2.UseSelectable = true;
            this.e2.UseStyleColors = true;
            this.e2.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // e3
            // 
            this.e3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e3.BackgroundImage")));
            this.e3.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e3.ForeColor = System.Drawing.Color.White;
            this.e3.Location = new System.Drawing.Point(170, 68);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(74, 15);
            this.e3.Style = MetroFramework.MetroColorStyle.Black;
            this.e3.TabIndex = 39;
            this.e3.TabStop = false;
            this.e3.Text = "Ethereum";
            this.e3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e3.UseCustomBackColor = true;
            this.e3.UseCustomForeColor = true;
            this.e3.UseSelectable = true;
            this.e3.UseStyleColors = true;
            this.e3.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // e4
            // 
            this.e4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e4.BackgroundImage")));
            this.e4.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e4.ForeColor = System.Drawing.Color.White;
            this.e4.Location = new System.Drawing.Point(250, 68);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(74, 15);
            this.e4.Style = MetroFramework.MetroColorStyle.Black;
            this.e4.TabIndex = 40;
            this.e4.TabStop = false;
            this.e4.Text = "Ripple";
            this.e4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e4.UseCustomBackColor = true;
            this.e4.UseCustomForeColor = true;
            this.e4.UseSelectable = true;
            this.e4.UseStyleColors = true;
            this.e4.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // e5
            // 
            this.e5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e5.BackgroundImage")));
            this.e5.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e5.ForeColor = System.Drawing.Color.White;
            this.e5.Location = new System.Drawing.Point(330, 68);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(74, 15);
            this.e5.Style = MetroFramework.MetroColorStyle.Black;
            this.e5.TabIndex = 41;
            this.e5.TabStop = false;
            this.e5.Text = "EOS";
            this.e5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e5.UseCustomBackColor = true;
            this.e5.UseCustomForeColor = true;
            this.e5.UseSelectable = true;
            this.e5.UseStyleColors = true;
            this.e5.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // e6
            // 
            this.e6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.e6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("e6.BackgroundImage")));
            this.e6.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.e6.ForeColor = System.Drawing.Color.White;
            this.e6.Location = new System.Drawing.Point(410, 68);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(74, 15);
            this.e6.Style = MetroFramework.MetroColorStyle.Black;
            this.e6.TabIndex = 42;
            this.e6.TabStop = false;
            this.e6.Text = "Bitcoin Cash";
            this.e6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.e6.UseCustomBackColor = true;
            this.e6.UseCustomForeColor = true;
            this.e6.UseSelectable = true;
            this.e6.UseStyleColors = true;
            this.e6.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton1.BackgroundImage")));
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.ForeColor = System.Drawing.Color.White;
            this.metroButton1.Location = new System.Drawing.Point(836, 68);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(50, 15);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton1.TabIndex = 43;
            this.metroButton1.TabStop = false;
            this.metroButton1.Text = "JPY";
            this.metroButton1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Visible = false;
            // 
            // metroButton2
            // 
            this.metroButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton2.BackgroundImage")));
            this.metroButton2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton2.ForeColor = System.Drawing.Color.White;
            this.metroButton2.Location = new System.Drawing.Point(780, 68);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(50, 15);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton2.TabIndex = 44;
            this.metroButton2.TabStop = false;
            this.metroButton2.Text = "CNY";
            this.metroButton2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroButton2.UseCustomBackColor = true;
            this.metroButton2.UseCustomForeColor = true;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.UseStyleColors = true;
            this.metroButton2.Visible = false;
            // 
            // metroButton3
            // 
            this.metroButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton3.BackgroundImage")));
            this.metroButton3.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton3.ForeColor = System.Drawing.Color.White;
            this.metroButton3.Location = new System.Drawing.Point(724, 68);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(50, 15);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton3.TabIndex = 45;
            this.metroButton3.TabStop = false;
            this.metroButton3.Text = "EUR";
            this.metroButton3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroButton3.UseCustomBackColor = true;
            this.metroButton3.UseCustomForeColor = true;
            this.metroButton3.UseSelectable = true;
            this.metroButton3.UseStyleColors = true;
            this.metroButton3.Visible = false;
            // 
            // metroButton4
            // 
            this.metroButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton4.BackgroundImage")));
            this.metroButton4.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton4.ForeColor = System.Drawing.Color.White;
            this.metroButton4.Location = new System.Drawing.Point(668, 68);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(50, 15);
            this.metroButton4.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton4.TabIndex = 46;
            this.metroButton4.TabStop = false;
            this.metroButton4.Text = "USD";
            this.metroButton4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroButton4.UseCustomBackColor = true;
            this.metroButton4.UseCustomForeColor = true;
            this.metroButton4.UseSelectable = true;
            this.metroButton4.UseStyleColors = true;
            this.metroButton4.Visible = false;
            // 
            // metroButton5
            // 
            this.metroButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton5.BackgroundImage")));
            this.metroButton5.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton5.ForeColor = System.Drawing.Color.White;
            this.metroButton5.Location = new System.Drawing.Point(612, 68);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(50, 15);
            this.metroButton5.Style = MetroFramework.MetroColorStyle.Black;
            this.metroButton5.TabIndex = 47;
            this.metroButton5.TabStop = false;
            this.metroButton5.Text = "KRW";
            this.metroButton5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroButton5.UseCustomBackColor = true;
            this.metroButton5.UseCustomForeColor = true;
            this.metroButton5.UseSelectable = true;
            this.metroButton5.UseStyleColors = true;
            this.metroButton5.Visible = false;
            // 
            // simple
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 90);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.metroButton5);
            this.Controls.Add(this.metroButton4);
            this.Controls.Add(this.metroButton3);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.e6);
            this.Controls.Add(this.e5);
            this.Controls.Add(this.e4);
            this.Controls.Add(this.e3);
            this.Controls.Add(this.e2);
            this.Controls.Add(this.e1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.setBar);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel18);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(901, 90);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(901, 90);
            this.Name = "simple";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.simple_Load);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroTrackBar setBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label N05;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label N06;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label N07;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label N01;
        private System.Windows.Forms.Label label14;
        private MetroFramework.Controls.MetroButton e1;
        private MetroFramework.Controls.MetroButton e2;
        private MetroFramework.Controls.MetroButton e3;
        private MetroFramework.Controls.MetroButton e4;
        private MetroFramework.Controls.MetroButton e5;
        private MetroFramework.Controls.MetroButton e6;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroButton metroButton5;
        public System.Windows.Forms.Label N02;
        public System.Windows.Forms.Label N03;
        public System.Windows.Forms.Label N04;
    }
}