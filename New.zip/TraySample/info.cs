﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Planet
{
    public partial class info : MetroFramework.Forms.MetroForm
    {
        public info()
        {
            InitializeComponent();
            this.TransparencyKey = Color.White;
            this.BackColor = Color.White;
        }

        private void info_Load(object sender, EventArgs e)
        { 
        }
    }
}
