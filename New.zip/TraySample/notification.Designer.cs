﻿namespace Planet
{
    partial class notification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(notification));
            this.bt1 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.N01 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.t1 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.t3 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.t5 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.t6 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.t4 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.t2 = new System.Windows.Forms.Label();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt1
            // 
            this.bt1.BackColor = System.Drawing.Color.Black;
            this.bt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt1.BackgroundImage")));
            this.bt1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.bt1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.bt1.ForeColor = System.Drawing.Color.White;
            this.bt1.Location = new System.Drawing.Point(21, 161);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(211, 40);
            this.bt1.TabIndex = 58;
            this.bt1.Text = "OK";
            this.bt1.UseCustomBackColor = true;
            this.bt1.UseCustomForeColor = true;
            this.bt1.UseSelectable = true;
            this.bt1.UseStyleColors = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Black;
            this.metroButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton1.BackgroundImage")));
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.ForeColor = System.Drawing.Color.White;
            this.metroButton1.Location = new System.Drawing.Point(238, 161);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(211, 40);
            this.metroButton1.TabIndex = 59;
            this.metroButton1.Text = "Open Website";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Adobe Devanagari", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(156, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 43);
            this.label1.TabIndex = 63;
            this.label1.Text = "Notification";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.N01);
            this.panel7.Location = new System.Drawing.Point(21, 69);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(115, 19);
            this.panel7.TabIndex = 64;
            // 
            // N01
            // 
            this.N01.AutoSize = true;
            this.N01.BackColor = System.Drawing.Color.Transparent;
            this.N01.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.N01.ForeColor = System.Drawing.Color.White;
            this.N01.Location = new System.Drawing.Point(2, 3);
            this.N01.Name = "N01";
            this.N01.Size = new System.Drawing.Size(27, 11);
            this.N01.TabIndex = 0;
            this.N01.Text = "Dac";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(21, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(115, 19);
            this.panel1.TabIndex = 65;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 11);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ethereum";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(21, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(115, 19);
            this.panel2.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(2, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 11);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ripple";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(238, 119);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(115, 19);
            this.panel3.TabIndex = 69;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(2, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 11);
            this.label4.TabIndex = 0;
            this.label4.Text = "Bitcoin Cash";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(238, 94);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(115, 19);
            this.panel4.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 11);
            this.label5.TabIndex = 0;
            this.label5.Text = "EOS";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label6);
            this.panel5.Location = new System.Drawing.Point(238, 69);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 19);
            this.panel5.TabIndex = 67;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 11);
            this.label6.TabIndex = 0;
            this.label6.Text = "Bitcoin";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.t1);
            this.panel6.Location = new System.Drawing.Point(142, 69);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(90, 19);
            this.panel6.TabIndex = 65;
            // 
            // t1
            // 
            this.t1.AutoSize = true;
            this.t1.BackColor = System.Drawing.Color.Transparent;
            this.t1.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t1.ForeColor = System.Drawing.Color.Lime;
            this.t1.Location = new System.Drawing.Point(2, 3);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(10, 11);
            this.t1.TabIndex = 0;
            this.t1.Text = "-";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.t3);
            this.panel8.Location = new System.Drawing.Point(142, 94);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(90, 19);
            this.panel8.TabIndex = 66;
            // 
            // t3
            // 
            this.t3.AutoSize = true;
            this.t3.BackColor = System.Drawing.Color.Transparent;
            this.t3.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t3.ForeColor = System.Drawing.Color.Lime;
            this.t3.Location = new System.Drawing.Point(2, 3);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(10, 11);
            this.t3.TabIndex = 0;
            this.t3.Text = "-";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.t5);
            this.panel9.Location = new System.Drawing.Point(142, 119);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(90, 19);
            this.panel9.TabIndex = 67;
            // 
            // t5
            // 
            this.t5.AutoSize = true;
            this.t5.BackColor = System.Drawing.Color.Transparent;
            this.t5.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t5.ForeColor = System.Drawing.Color.Lime;
            this.t5.Location = new System.Drawing.Point(2, 3);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(10, 11);
            this.t5.TabIndex = 0;
            this.t5.Text = "-";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.t6);
            this.panel10.Location = new System.Drawing.Point(359, 119);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(90, 19);
            this.panel10.TabIndex = 70;
            // 
            // t6
            // 
            this.t6.AutoSize = true;
            this.t6.BackColor = System.Drawing.Color.Transparent;
            this.t6.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t6.ForeColor = System.Drawing.Color.Lime;
            this.t6.Location = new System.Drawing.Point(2, 3);
            this.t6.Name = "t6";
            this.t6.Size = new System.Drawing.Size(10, 11);
            this.t6.TabIndex = 0;
            this.t6.Text = "-";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.t4);
            this.panel11.Location = new System.Drawing.Point(359, 94);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(90, 19);
            this.panel11.TabIndex = 69;
            // 
            // t4
            // 
            this.t4.AutoSize = true;
            this.t4.BackColor = System.Drawing.Color.Transparent;
            this.t4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t4.ForeColor = System.Drawing.Color.Lime;
            this.t4.Location = new System.Drawing.Point(2, 3);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(10, 11);
            this.t4.TabIndex = 0;
            this.t4.Text = "-";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.t2);
            this.panel12.Location = new System.Drawing.Point(359, 69);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(90, 19);
            this.panel12.TabIndex = 68;
            // 
            // t2
            // 
            this.t2.AutoSize = true;
            this.t2.BackColor = System.Drawing.Color.Transparent;
            this.t2.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t2.ForeColor = System.Drawing.Color.Lime;
            this.t2.Location = new System.Drawing.Point(2, 3);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(10, 11);
            this.t2.TabIndex = 0;
            this.t2.Text = "-";
            // 
            // notification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 220);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.bt1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(470, 220);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(470, 220);
            this.Name = "notification";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.notification_Load);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton bt1;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label N01;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label t1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label t3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label t5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label t6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label t4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label t2;
    }
}