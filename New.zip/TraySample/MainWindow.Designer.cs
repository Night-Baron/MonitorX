﻿namespace TraySample
{
    partial class MainWindow
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openMainScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openSmallScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detailViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.price_panel = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.v2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.v1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel23 = new System.Windows.Forms.Panel();
            this.usd07 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.n7_2 = new System.Windows.Forms.TextBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.usd06 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.usd01 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.usd02 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.usd03 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.t7_2 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.usd04 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.Set12 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.usd05 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.Set11 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.Set10 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.Set9 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.Set8 = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.Set7 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.panel35 = new System.Windows.Forms.Panel();
            this.Set6 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.Set5 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.Set4 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.Set3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.Set2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Set1 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.t9 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.t8 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.t7 = new System.Windows.Forms.Label();
            this.n9 = new System.Windows.Forms.TextBox();
            this.n8 = new System.Windows.Forms.TextBox();
            this.n7 = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.name = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.t1 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.t2 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.t3 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.t4 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.t5 = new System.Windows.Forms.Label();
            this.n5 = new System.Windows.Forms.TextBox();
            this.n4 = new System.Windows.Forms.TextBox();
            this.n3 = new System.Windows.Forms.TextBox();
            this.n2 = new System.Windows.Forms.TextBox();
            this.n1 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.la01 = new System.Windows.Forms.Label();
            this.c1 = new System.Windows.Forms.PictureBox();
            this.b1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.la02 = new System.Windows.Forms.Label();
            this.c2 = new System.Windows.Forms.PictureBox();
            this.b2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.la03 = new System.Windows.Forms.Label();
            this.c3 = new System.Windows.Forms.PictureBox();
            this.b3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.la04 = new System.Windows.Forms.Label();
            this.c4 = new System.Windows.Forms.PictureBox();
            this.b4 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.la05 = new System.Windows.Forms.Label();
            this.c5 = new System.Windows.Forms.PictureBox();
            this.b5 = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.la06 = new System.Windows.Forms.Label();
            this.c6 = new System.Windows.Forms.PictureBox();
            this.b6 = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.la07 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.c7 = new System.Windows.Forms.PictureBox();
            this.b7 = new System.Windows.Forms.PictureBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.la08 = new System.Windows.Forms.Label();
            this.c9 = new System.Windows.Forms.PictureBox();
            this.b9 = new System.Windows.Forms.PictureBox();
            this.la09 = new System.Windows.Forms.Label();
            this.c8 = new System.Windows.Forms.PictureBox();
            this.b8 = new System.Windows.Forms.PictureBox();
            this.Front_page = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.Main01 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ddlTime = new System.Windows.Forms.ComboBox();
            this.ddlCoin = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip1.SuspendLayout();
            this.price_panel.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b4)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b5)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b6)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b7)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b8)).BeginInit();
            this.Front_page.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "WatchDocks Beta";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.contextMenuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("contextMenuStrip1.BackgroundImage")));
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openMainScreenToolStripMenuItem,
            this.openSmallScreenToolStripMenuItem,
            this.detailViewToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.ExitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(146, 134);
            this.contextMenuStrip1.Text = "X-Monitor";
            // 
            // openMainScreenToolStripMenuItem
            // 
            this.openMainScreenToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("openMainScreenToolStripMenuItem.BackgroundImage")));
            this.openMainScreenToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.openMainScreenToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.openMainScreenToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openMainScreenToolStripMenuItem.Image")));
            this.openMainScreenToolStripMenuItem.Name = "openMainScreenToolStripMenuItem";
            this.openMainScreenToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.openMainScreenToolStripMenuItem.Text = "Main Screen";
            this.openMainScreenToolStripMenuItem.Click += new System.EventHandler(this.openMainScreenToolStripMenuItem_Click);
            // 
            // openSmallScreenToolStripMenuItem
            // 
            this.openSmallScreenToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("openSmallScreenToolStripMenuItem.BackgroundImage")));
            this.openSmallScreenToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.openSmallScreenToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.openSmallScreenToolStripMenuItem.Name = "openSmallScreenToolStripMenuItem";
            this.openSmallScreenToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.openSmallScreenToolStripMenuItem.Text = "Small Screen";
            this.openSmallScreenToolStripMenuItem.Click += new System.EventHandler(this.openSmallScreenToolStripMenuItem_Click);
            // 
            // detailViewToolStripMenuItem
            // 
            this.detailViewToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("detailViewToolStripMenuItem.BackgroundImage")));
            this.detailViewToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.detailViewToolStripMenuItem.Name = "detailViewToolStripMenuItem";
            this.detailViewToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.detailViewToolStripMenuItem.Text = "Detail View";
            this.detailViewToolStripMenuItem.Click += new System.EventHandler(this.detailViewToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("settingToolStripMenuItem.BackgroundImage")));
            this.settingToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.settingToolStripMenuItem.Text = "Setting";
            this.settingToolStripMenuItem.Click += new System.EventHandler(this.settingToolStripMenuItem_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitToolStripMenuItem.BackgroundImage")));
            this.ExitToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ExitToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click_1);
            // 
            // price_panel
            // 
            this.price_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.price_panel.Controls.Add(this.panel38);
            this.price_panel.Controls.Add(this.panel30);
            this.price_panel.Controls.Add(this.textBox2);
            this.price_panel.Controls.Add(this.panel31);
            this.price_panel.Controls.Add(this.textBox3);
            this.price_panel.Controls.Add(this.panel23);
            this.price_panel.Controls.Add(this.panel5);
            this.price_panel.Controls.Add(this.textBox1);
            this.price_panel.Controls.Add(this.n7_2);
            this.price_panel.Controls.Add(this.panel24);
            this.price_panel.Controls.Add(this.panel6);
            this.price_panel.Controls.Add(this.panel25);
            this.price_panel.Controls.Add(this.panel26);
            this.price_panel.Controls.Add(this.panel27);
            this.price_panel.Controls.Add(this.panel9);
            this.price_panel.Controls.Add(this.panel28);
            this.price_panel.Controls.Add(this.panel36);
            this.price_panel.Controls.Add(this.panel29);
            this.price_panel.Controls.Add(this.panel37);
            this.price_panel.Controls.Add(this.panel40);
            this.price_panel.Controls.Add(this.panel41);
            this.price_panel.Controls.Add(this.panel42);
            this.price_panel.Controls.Add(this.panel43);
            this.price_panel.Controls.Add(this.textBox9);
            this.price_panel.Controls.Add(this.panel35);
            this.price_panel.Controls.Add(this.panel34);
            this.price_panel.Controls.Add(this.panel33);
            this.price_panel.Controls.Add(this.panel32);
            this.price_panel.Controls.Add(this.panel10);
            this.price_panel.Controls.Add(this.panel8);
            this.price_panel.Controls.Add(this.textBox12);
            this.price_panel.Controls.Add(this.textBox11);
            this.price_panel.Controls.Add(this.textBox10);
            this.price_panel.Controls.Add(this.panel22);
            this.price_panel.Controls.Add(this.panel21);
            this.price_panel.Controls.Add(this.panel20);
            this.price_panel.Controls.Add(this.n9);
            this.price_panel.Controls.Add(this.n8);
            this.price_panel.Controls.Add(this.n7);
            this.price_panel.Controls.Add(this.panel19);
            this.price_panel.Controls.Add(this.panel18);
            this.price_panel.Controls.Add(this.panel17);
            this.price_panel.Controls.Add(this.panel16);
            this.price_panel.Controls.Add(this.panel15);
            this.price_panel.Controls.Add(this.panel14);
            this.price_panel.Controls.Add(this.n5);
            this.price_panel.Controls.Add(this.n4);
            this.price_panel.Controls.Add(this.n3);
            this.price_panel.Controls.Add(this.n2);
            this.price_panel.Controls.Add(this.n1);
            this.price_panel.Controls.Add(this.panel7);
            this.price_panel.Location = new System.Drawing.Point(219, 51);
            this.price_panel.Name = "price_panel";
            this.price_panel.Size = new System.Drawing.Size(902, 537);
            this.price_panel.TabIndex = 7;
            this.price_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.price_panel_Paint);
            // 
            // panel30
            // 
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.v2);
            this.panel30.Location = new System.Drawing.Point(565, 258);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(322, 21);
            this.panel30.TabIndex = 22;
            // 
            // v2
            // 
            this.v2.BackColor = System.Drawing.Color.Transparent;
            this.v2.Dock = System.Windows.Forms.DockStyle.Left;
            this.v2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.v2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.v2.Location = new System.Drawing.Point(0, 0);
            this.v2.Name = "v2";
            this.v2.Size = new System.Drawing.Size(321, 19);
            this.v2.TabIndex = 0;
            this.v2.Text = "-";
            this.v2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(411, 258);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(148, 21);
            this.textBox2.TabIndex = 58;
            this.textBox2.Text = "Volume 7 days";
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.v1);
            this.panel31.Location = new System.Drawing.Point(565, 231);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(322, 21);
            this.panel31.TabIndex = 21;
            // 
            // v1
            // 
            this.v1.BackColor = System.Drawing.Color.Transparent;
            this.v1.Dock = System.Windows.Forms.DockStyle.Left;
            this.v1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.v1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.v1.Location = new System.Drawing.Point(0, 0);
            this.v1.Name = "v1";
            this.v1.Size = new System.Drawing.Size(321, 19);
            this.v1.TabIndex = 0;
            this.v1.Text = "-";
            this.v1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(411, 231);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(148, 21);
            this.textBox3.TabIndex = 57;
            this.textBox3.Text = "Volume 1 day";
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.usd07);
            this.panel23.Location = new System.Drawing.Point(411, 205);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(148, 21);
            this.panel23.TabIndex = 56;
            // 
            // usd07
            // 
            this.usd07.BackColor = System.Drawing.Color.Transparent;
            this.usd07.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd07.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd07.ForeColor = System.Drawing.Color.LightGreen;
            this.usd07.Location = new System.Drawing.Point(0, 0);
            this.usd07.Name = "usd07";
            this.usd07.Size = new System.Drawing.Size(147, 19);
            this.usd07.TabIndex = 0;
            this.usd07.Text = "-";
            this.usd07.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Location = new System.Drawing.Point(729, 205);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(158, 21);
            this.panel5.TabIndex = 50;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(0, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(156, 19);
            this.label13.TabIndex = 0;
            this.label13.Text = "-";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(411, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 21);
            this.textBox1.TabIndex = 55;
            this.textBox1.Text = "Value (USD)";
            // 
            // n7_2
            // 
            this.n7_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n7_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n7_2.Enabled = false;
            this.n7_2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n7_2.ForeColor = System.Drawing.Color.White;
            this.n7_2.Location = new System.Drawing.Point(131, 205);
            this.n7_2.Name = "n7_2";
            this.n7_2.Size = new System.Drawing.Size(120, 21);
            this.n7_2.TabIndex = 50;
            this.n7_2.Text = "Change Rate";
            // 
            // panel24
            // 
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.usd06);
            this.panel24.Location = new System.Drawing.Point(411, 178);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(148, 21);
            this.panel24.TabIndex = 49;
            // 
            // usd06
            // 
            this.usd06.BackColor = System.Drawing.Color.Transparent;
            this.usd06.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd06.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd06.ForeColor = System.Drawing.Color.LightGreen;
            this.usd06.Location = new System.Drawing.Point(0, 0);
            this.usd06.Name = "usd06";
            this.usd06.Size = new System.Drawing.Size(147, 19);
            this.usd06.TabIndex = 0;
            this.usd06.Text = "-";
            this.usd06.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label14);
            this.panel6.Location = new System.Drawing.Point(565, 205);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(158, 21);
            this.panel6.TabIndex = 49;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 19);
            this.label14.TabIndex = 0;
            this.label14.Text = "-";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.usd01);
            this.panel25.Location = new System.Drawing.Point(411, 43);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(148, 21);
            this.panel25.TabIndex = 54;
            // 
            // usd01
            // 
            this.usd01.BackColor = System.Drawing.Color.Transparent;
            this.usd01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.usd01.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd01.ForeColor = System.Drawing.Color.LightGreen;
            this.usd01.Location = new System.Drawing.Point(0, 0);
            this.usd01.Name = "usd01";
            this.usd01.Size = new System.Drawing.Size(146, 19);
            this.usd01.TabIndex = 0;
            this.usd01.Text = "-";
            this.usd01.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.usd02);
            this.panel26.Location = new System.Drawing.Point(411, 70);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(148, 21);
            this.panel26.TabIndex = 53;
            // 
            // usd02
            // 
            this.usd02.BackColor = System.Drawing.Color.Transparent;
            this.usd02.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd02.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd02.ForeColor = System.Drawing.Color.LightGreen;
            this.usd02.Location = new System.Drawing.Point(0, 0);
            this.usd02.Name = "usd02";
            this.usd02.Size = new System.Drawing.Size(147, 19);
            this.usd02.TabIndex = 0;
            this.usd02.Text = "-";
            this.usd02.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.usd03);
            this.panel27.Location = new System.Drawing.Point(411, 97);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(148, 21);
            this.panel27.TabIndex = 52;
            // 
            // usd03
            // 
            this.usd03.BackColor = System.Drawing.Color.Transparent;
            this.usd03.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd03.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd03.ForeColor = System.Drawing.Color.LightGreen;
            this.usd03.Location = new System.Drawing.Point(0, 0);
            this.usd03.Name = "usd03";
            this.usd03.Size = new System.Drawing.Size(147, 19);
            this.usd03.TabIndex = 0;
            this.usd03.Text = "-";
            this.usd03.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.t7_2);
            this.panel9.Location = new System.Drawing.Point(257, 205);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(148, 21);
            this.panel9.TabIndex = 48;
            // 
            // t7_2
            // 
            this.t7_2.BackColor = System.Drawing.Color.Transparent;
            this.t7_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.t7_2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t7_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t7_2.Location = new System.Drawing.Point(0, 0);
            this.t7_2.Name = "t7_2";
            this.t7_2.Size = new System.Drawing.Size(147, 19);
            this.t7_2.TabIndex = 0;
            this.t7_2.Text = "-";
            this.t7_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel28
            // 
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.usd04);
            this.panel28.Location = new System.Drawing.Point(411, 124);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(148, 21);
            this.panel28.TabIndex = 51;
            // 
            // usd04
            // 
            this.usd04.BackColor = System.Drawing.Color.Transparent;
            this.usd04.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd04.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd04.ForeColor = System.Drawing.Color.LightGreen;
            this.usd04.Location = new System.Drawing.Point(0, 0);
            this.usd04.Name = "usd04";
            this.usd04.Size = new System.Drawing.Size(147, 19);
            this.usd04.TabIndex = 0;
            this.usd04.Text = "-";
            this.usd04.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel36
            // 
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.Set12);
            this.panel36.Location = new System.Drawing.Point(729, 178);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(158, 21);
            this.panel36.TabIndex = 47;
            // 
            // Set12
            // 
            this.Set12.BackColor = System.Drawing.Color.Transparent;
            this.Set12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set12.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set12.ForeColor = System.Drawing.Color.Red;
            this.Set12.Location = new System.Drawing.Point(0, 0);
            this.Set12.Name = "Set12";
            this.Set12.Size = new System.Drawing.Size(156, 19);
            this.Set12.TabIndex = 0;
            this.Set12.Text = "-";
            this.Set12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.usd05);
            this.panel29.Location = new System.Drawing.Point(411, 151);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(148, 21);
            this.panel29.TabIndex = 50;
            // 
            // usd05
            // 
            this.usd05.BackColor = System.Drawing.Color.Transparent;
            this.usd05.Dock = System.Windows.Forms.DockStyle.Left;
            this.usd05.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.usd05.ForeColor = System.Drawing.Color.LightGreen;
            this.usd05.Location = new System.Drawing.Point(0, 0);
            this.usd05.Name = "usd05";
            this.usd05.Size = new System.Drawing.Size(147, 19);
            this.usd05.TabIndex = 0;
            this.usd05.Text = "-";
            this.usd05.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel37
            // 
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.Controls.Add(this.Set11);
            this.panel37.Location = new System.Drawing.Point(729, 151);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(158, 21);
            this.panel37.TabIndex = 45;
            // 
            // Set11
            // 
            this.Set11.BackColor = System.Drawing.Color.Transparent;
            this.Set11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set11.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set11.ForeColor = System.Drawing.Color.Red;
            this.Set11.Location = new System.Drawing.Point(0, 0);
            this.Set11.Name = "Set11";
            this.Set11.Size = new System.Drawing.Size(156, 19);
            this.Set11.TabIndex = 0;
            this.Set11.Text = "-";
            this.Set11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel40
            // 
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.Set10);
            this.panel40.Location = new System.Drawing.Point(729, 124);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(158, 21);
            this.panel40.TabIndex = 44;
            // 
            // Set10
            // 
            this.Set10.BackColor = System.Drawing.Color.Transparent;
            this.Set10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set10.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set10.ForeColor = System.Drawing.Color.Red;
            this.Set10.Location = new System.Drawing.Point(0, 0);
            this.Set10.Name = "Set10";
            this.Set10.Size = new System.Drawing.Size(156, 19);
            this.Set10.TabIndex = 0;
            this.Set10.Text = "-";
            this.Set10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel41
            // 
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.Set9);
            this.panel41.Location = new System.Drawing.Point(729, 97);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(158, 21);
            this.panel41.TabIndex = 43;
            // 
            // Set9
            // 
            this.Set9.BackColor = System.Drawing.Color.Transparent;
            this.Set9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set9.ForeColor = System.Drawing.Color.Red;
            this.Set9.Location = new System.Drawing.Point(0, 0);
            this.Set9.Name = "Set9";
            this.Set9.Size = new System.Drawing.Size(156, 19);
            this.Set9.TabIndex = 0;
            this.Set9.Text = "-";
            this.Set9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel42
            // 
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.Set8);
            this.panel42.Location = new System.Drawing.Point(729, 70);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(158, 21);
            this.panel42.TabIndex = 42;
            // 
            // Set8
            // 
            this.Set8.BackColor = System.Drawing.Color.Transparent;
            this.Set8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set8.ForeColor = System.Drawing.Color.Red;
            this.Set8.Location = new System.Drawing.Point(0, 0);
            this.Set8.Name = "Set8";
            this.Set8.Size = new System.Drawing.Size(156, 19);
            this.Set8.TabIndex = 0;
            this.Set8.Text = "-";
            this.Set8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel43
            // 
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.Controls.Add(this.Set7);
            this.panel43.Location = new System.Drawing.Point(729, 43);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(158, 21);
            this.panel43.TabIndex = 41;
            // 
            // Set7
            // 
            this.Set7.BackColor = System.Drawing.Color.Transparent;
            this.Set7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set7.ForeColor = System.Drawing.Color.Red;
            this.Set7.Location = new System.Drawing.Point(0, 0);
            this.Set7.Name = "Set7";
            this.Set7.Size = new System.Drawing.Size(156, 19);
            this.Set7.TabIndex = 0;
            this.Set7.Text = "-";
            this.Set7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Enabled = false;
            this.textBox9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox9.ForeColor = System.Drawing.Color.Red;
            this.textBox9.Location = new System.Drawing.Point(729, 16);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(158, 21);
            this.textBox9.TabIndex = 46;
            this.textBox9.Text = "Setting (Low)";
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.Set6);
            this.panel35.Location = new System.Drawing.Point(565, 178);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(158, 21);
            this.panel35.TabIndex = 28;
            // 
            // Set6
            // 
            this.Set6.BackColor = System.Drawing.Color.Transparent;
            this.Set6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set6.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set6.Location = new System.Drawing.Point(0, 0);
            this.Set6.Name = "Set6";
            this.Set6.Size = new System.Drawing.Size(156, 19);
            this.Set6.TabIndex = 0;
            this.Set6.Text = "-";
            this.Set6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.Set5);
            this.panel34.Location = new System.Drawing.Point(565, 151);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(158, 21);
            this.panel34.TabIndex = 27;
            // 
            // Set5
            // 
            this.Set5.BackColor = System.Drawing.Color.Transparent;
            this.Set5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set5.Location = new System.Drawing.Point(0, 0);
            this.Set5.Name = "Set5";
            this.Set5.Size = new System.Drawing.Size(156, 19);
            this.Set5.TabIndex = 0;
            this.Set5.Text = "-";
            this.Set5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel33
            // 
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Controls.Add(this.Set4);
            this.panel33.Location = new System.Drawing.Point(565, 124);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(158, 21);
            this.panel33.TabIndex = 26;
            // 
            // Set4
            // 
            this.Set4.BackColor = System.Drawing.Color.Transparent;
            this.Set4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set4.Location = new System.Drawing.Point(0, 0);
            this.Set4.Name = "Set4";
            this.Set4.Size = new System.Drawing.Size(156, 19);
            this.Set4.TabIndex = 0;
            this.Set4.Text = "-";
            this.Set4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel32
            // 
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.Set3);
            this.panel32.Location = new System.Drawing.Point(565, 97);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(158, 21);
            this.panel32.TabIndex = 25;
            // 
            // Set3
            // 
            this.Set3.BackColor = System.Drawing.Color.Transparent;
            this.Set3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set3.Location = new System.Drawing.Point(0, 0);
            this.Set3.Name = "Set3";
            this.Set3.Size = new System.Drawing.Size(156, 19);
            this.Set3.TabIndex = 0;
            this.Set3.Text = "-";
            this.Set3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.Set2);
            this.panel10.Location = new System.Drawing.Point(565, 70);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(158, 21);
            this.panel10.TabIndex = 24;
            // 
            // Set2
            // 
            this.Set2.BackColor = System.Drawing.Color.Transparent;
            this.Set2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set2.Location = new System.Drawing.Point(0, 0);
            this.Set2.Name = "Set2";
            this.Set2.Size = new System.Drawing.Size(156, 19);
            this.Set2.TabIndex = 0;
            this.Set2.Text = "-";
            this.Set2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.Set1);
            this.panel8.Location = new System.Drawing.Point(565, 43);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(158, 21);
            this.panel8.TabIndex = 23;
            // 
            // Set1
            // 
            this.Set1.BackColor = System.Drawing.Color.Transparent;
            this.Set1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Set1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Set1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Set1.Location = new System.Drawing.Point(0, 0);
            this.Set1.Name = "Set1";
            this.Set1.Size = new System.Drawing.Size(156, 19);
            this.Set1.TabIndex = 0;
            this.Set1.Text = "-";
            this.Set1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Enabled = false;
            this.textBox12.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.textBox12.Location = new System.Drawing.Point(565, 16);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(158, 21);
            this.textBox12.TabIndex = 27;
            this.textBox12.Text = "Setting (High)";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Enabled = false;
            this.textBox11.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox11.ForeColor = System.Drawing.Color.White;
            this.textBox11.Location = new System.Drawing.Point(257, 16);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(148, 21);
            this.textBox11.TabIndex = 26;
            this.textBox11.Text = "Value (KRW)";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Enabled = false;
            this.textBox10.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox10.ForeColor = System.Drawing.Color.White;
            this.textBox10.Location = new System.Drawing.Point(131, 16);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(120, 21);
            this.textBox10.TabIndex = 23;
            this.textBox10.Text = "Category";
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.t9);
            this.panel22.Location = new System.Drawing.Point(131, 258);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(274, 21);
            this.panel22.TabIndex = 20;
            // 
            // t9
            // 
            this.t9.BackColor = System.Drawing.Color.Transparent;
            this.t9.Dock = System.Windows.Forms.DockStyle.Left;
            this.t9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t9.Location = new System.Drawing.Point(0, 0);
            this.t9.Name = "t9";
            this.t9.Size = new System.Drawing.Size(273, 19);
            this.t9.TabIndex = 0;
            this.t9.Text = "-";
            this.t9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.t8);
            this.panel21.Location = new System.Drawing.Point(131, 231);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(274, 21);
            this.panel21.TabIndex = 19;
            // 
            // t8
            // 
            this.t8.BackColor = System.Drawing.Color.Transparent;
            this.t8.Dock = System.Windows.Forms.DockStyle.Left;
            this.t8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t8.Location = new System.Drawing.Point(0, 0);
            this.t8.Name = "t8";
            this.t8.Size = new System.Drawing.Size(273, 19);
            this.t8.TabIndex = 0;
            this.t8.Text = "-";
            this.t8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.t7);
            this.panel20.Location = new System.Drawing.Point(257, 178);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(148, 21);
            this.panel20.TabIndex = 18;
            // 
            // t7
            // 
            this.t7.BackColor = System.Drawing.Color.Transparent;
            this.t7.Dock = System.Windows.Forms.DockStyle.Left;
            this.t7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t7.Location = new System.Drawing.Point(0, 0);
            this.t7.Name = "t7";
            this.t7.Size = new System.Drawing.Size(147, 19);
            this.t7.TabIndex = 0;
            this.t7.Text = "-";
            this.t7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // n9
            // 
            this.n9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n9.Enabled = false;
            this.n9.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n9.ForeColor = System.Drawing.Color.White;
            this.n9.Location = new System.Drawing.Point(14, 258);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(111, 21);
            this.n9.TabIndex = 25;
            this.n9.Text = "Data Value";
            // 
            // n8
            // 
            this.n8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n8.Enabled = false;
            this.n8.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n8.ForeColor = System.Drawing.Color.White;
            this.n8.Location = new System.Drawing.Point(14, 231);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(111, 21);
            this.n8.TabIndex = 24;
            this.n8.Text = "Current Time";
            // 
            // n7
            // 
            this.n7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n7.Enabled = false;
            this.n7.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n7.ForeColor = System.Drawing.Color.White;
            this.n7.Location = new System.Drawing.Point(131, 178);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(120, 21);
            this.n7.TabIndex = 23;
            this.n7.Text = "Change";
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.name);
            this.panel19.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel19.Location = new System.Drawing.Point(14, 16);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(111, 21);
            this.panel19.TabIndex = 18;
            // 
            // name
            // 
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.name.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.name.ForeColor = System.Drawing.Color.Lime;
            this.name.Location = new System.Drawing.Point(0, 0);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(109, 19);
            this.name.TabIndex = 0;
            this.name.Text = "-";
            this.name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.t1);
            this.panel18.Location = new System.Drawing.Point(257, 43);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(148, 21);
            this.panel18.TabIndex = 22;
            // 
            // t1
            // 
            this.t1.BackColor = System.Drawing.Color.Transparent;
            this.t1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.t1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t1.Location = new System.Drawing.Point(0, 0);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(146, 19);
            this.t1.TabIndex = 0;
            this.t1.Text = "-";
            this.t1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.t2);
            this.panel17.Location = new System.Drawing.Point(257, 70);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(148, 21);
            this.panel17.TabIndex = 21;
            // 
            // t2
            // 
            this.t2.BackColor = System.Drawing.Color.Transparent;
            this.t2.Dock = System.Windows.Forms.DockStyle.Left;
            this.t2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t2.Location = new System.Drawing.Point(0, 0);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(147, 19);
            this.t2.TabIndex = 0;
            this.t2.Text = "-";
            this.t2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.t3);
            this.panel16.Location = new System.Drawing.Point(257, 97);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(148, 21);
            this.panel16.TabIndex = 20;
            // 
            // t3
            // 
            this.t3.BackColor = System.Drawing.Color.Transparent;
            this.t3.Dock = System.Windows.Forms.DockStyle.Left;
            this.t3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t3.Location = new System.Drawing.Point(0, 0);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(147, 19);
            this.t3.TabIndex = 0;
            this.t3.Text = "-";
            this.t3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.t4);
            this.panel15.Location = new System.Drawing.Point(257, 124);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(148, 21);
            this.panel15.TabIndex = 19;
            // 
            // t4
            // 
            this.t4.BackColor = System.Drawing.Color.Transparent;
            this.t4.Dock = System.Windows.Forms.DockStyle.Left;
            this.t4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t4.Location = new System.Drawing.Point(0, 0);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(147, 19);
            this.t4.TabIndex = 0;
            this.t4.Text = "-";
            this.t4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.t5);
            this.panel14.Location = new System.Drawing.Point(257, 151);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(148, 21);
            this.panel14.TabIndex = 18;
            // 
            // t5
            // 
            this.t5.BackColor = System.Drawing.Color.Transparent;
            this.t5.Dock = System.Windows.Forms.DockStyle.Left;
            this.t5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.t5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t5.Location = new System.Drawing.Point(0, 0);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(147, 19);
            this.t5.TabIndex = 0;
            this.t5.Text = "-";
            this.t5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // n5
            // 
            this.n5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n5.Enabled = false;
            this.n5.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n5.ForeColor = System.Drawing.Color.White;
            this.n5.Location = new System.Drawing.Point(131, 151);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(120, 21);
            this.n5.TabIndex = 14;
            this.n5.Text = "Minimum Price";
            // 
            // n4
            // 
            this.n4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n4.Enabled = false;
            this.n4.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n4.ForeColor = System.Drawing.Color.White;
            this.n4.Location = new System.Drawing.Point(131, 124);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(120, 21);
            this.n4.TabIndex = 13;
            this.n4.Text = "Maximum Price";
            // 
            // n3
            // 
            this.n3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n3.Enabled = false;
            this.n3.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n3.ForeColor = System.Drawing.Color.White;
            this.n3.Location = new System.Drawing.Point(132, 97);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(120, 21);
            this.n3.TabIndex = 12;
            this.n3.Text = "Average Price";
            // 
            // n2
            // 
            this.n2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n2.Enabled = false;
            this.n2.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n2.ForeColor = System.Drawing.Color.White;
            this.n2.Location = new System.Drawing.Point(131, 70);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(120, 21);
            this.n2.TabIndex = 11;
            this.n2.Text = "Closing Price";
            // 
            // n1
            // 
            this.n1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.n1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n1.Enabled = false;
            this.n1.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n1.ForeColor = System.Drawing.Color.White;
            this.n1.Location = new System.Drawing.Point(131, 43);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(120, 21);
            this.n1.TabIndex = 10;
            this.n1.Text = "Opening Price";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Location = new System.Drawing.Point(14, 43);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(111, 183);
            this.panel7.TabIndex = 6;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroPanel2.BackgroundImage")));
            this.metroPanel2.Controls.Add(this.label11);
            this.metroPanel2.Controls.Add(this.label10);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(207, 83);
            this.metroPanel2.TabIndex = 7;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("MS PGothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(19, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 15);
            this.label11.TabIndex = 66;
            this.label11.Text = "Price Monitoring System";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(16, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 33);
            this.label10.TabIndex = 65;
            this.label10.Text = "X Monitor II";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.la01);
            this.panel1.Controls.Add(this.c1);
            this.panel1.Controls.Add(this.b1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(207, 46);
            this.panel1.TabIndex = 8;
            // 
            // la01
            // 
            this.la01.AutoSize = true;
            this.la01.BackColor = System.Drawing.Color.Transparent;
            this.la01.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la01.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la01.Location = new System.Drawing.Point(24, 14);
            this.la01.Name = "la01";
            this.la01.Size = new System.Drawing.Size(39, 16);
            this.la01.TabIndex = 3;
            this.la01.Text = "Main";
            this.la01.Click += new System.EventHandler(this.label3_Click);
            // 
            // c1
            // 
            this.c1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c1.Dock = System.Windows.Forms.DockStyle.Left;
            this.c1.Location = new System.Drawing.Point(0, 0);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(20, 46);
            this.c1.TabIndex = 0;
            this.c1.TabStop = false;
            this.c1.Visible = false;
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Transparent;
            this.b1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b1.BackgroundImage")));
            this.b1.Location = new System.Drawing.Point(0, 0);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(207, 46);
            this.b1.TabIndex = 1;
            this.b1.TabStop = false;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.la02);
            this.panel2.Controls.Add(this.c2);
            this.panel2.Controls.Add(this.b2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 129);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(207, 46);
            this.panel2.TabIndex = 9;
            // 
            // la02
            // 
            this.la02.AutoSize = true;
            this.la02.BackColor = System.Drawing.Color.Transparent;
            this.la02.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la02.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la02.Location = new System.Drawing.Point(24, 15);
            this.la02.Name = "la02";
            this.la02.Size = new System.Drawing.Size(54, 16);
            this.la02.TabIndex = 2;
            this.la02.Text = "Bitcoin";
            this.la02.Click += new System.EventHandler(this.la02_Click);
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c2.Dock = System.Windows.Forms.DockStyle.Left;
            this.c2.Location = new System.Drawing.Point(0, 0);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(20, 46);
            this.c2.TabIndex = 0;
            this.c2.TabStop = false;
            this.c2.Visible = false;
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Transparent;
            this.b2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b2.BackgroundImage")));
            this.b2.Dock = System.Windows.Forms.DockStyle.Right;
            this.b2.Location = new System.Drawing.Point(0, 0);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(207, 46);
            this.b2.TabIndex = 1;
            this.b2.TabStop = false;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.la03);
            this.panel3.Controls.Add(this.c3);
            this.panel3.Controls.Add(this.b3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 175);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(207, 46);
            this.panel3.TabIndex = 10;
            // 
            // la03
            // 
            this.la03.AutoSize = true;
            this.la03.BackColor = System.Drawing.Color.Transparent;
            this.la03.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la03.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la03.Location = new System.Drawing.Point(24, 15);
            this.la03.Name = "la03";
            this.la03.Size = new System.Drawing.Size(73, 16);
            this.la03.TabIndex = 3;
            this.la03.Text = "Ethereum";
            this.la03.Click += new System.EventHandler(this.la03_Click);
            // 
            // c3
            // 
            this.c3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c3.Dock = System.Windows.Forms.DockStyle.Left;
            this.c3.Location = new System.Drawing.Point(0, 0);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(20, 46);
            this.c3.TabIndex = 0;
            this.c3.TabStop = false;
            this.c3.Visible = false;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Transparent;
            this.b3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b3.BackgroundImage")));
            this.b3.Dock = System.Windows.Forms.DockStyle.Right;
            this.b3.Location = new System.Drawing.Point(0, 0);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(207, 46);
            this.b3.TabIndex = 1;
            this.b3.TabStop = false;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.la04);
            this.panel4.Controls.Add(this.c4);
            this.panel4.Controls.Add(this.b4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 221);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(207, 46);
            this.panel4.TabIndex = 11;
            // 
            // la04
            // 
            this.la04.AutoSize = true;
            this.la04.BackColor = System.Drawing.Color.Transparent;
            this.la04.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la04.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la04.Location = new System.Drawing.Point(24, 15);
            this.la04.Name = "la04";
            this.la04.Size = new System.Drawing.Size(48, 16);
            this.la04.TabIndex = 4;
            this.la04.Text = "Ripple";
            this.la04.Click += new System.EventHandler(this.la04_Click);
            // 
            // c4
            // 
            this.c4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c4.Dock = System.Windows.Forms.DockStyle.Left;
            this.c4.Location = new System.Drawing.Point(0, 0);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(20, 46);
            this.c4.TabIndex = 0;
            this.c4.TabStop = false;
            this.c4.Visible = false;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Transparent;
            this.b4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b4.BackgroundImage")));
            this.b4.Dock = System.Windows.Forms.DockStyle.Right;
            this.b4.Location = new System.Drawing.Point(0, 0);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(207, 46);
            this.b4.TabIndex = 1;
            this.b4.TabStop = false;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.la05);
            this.panel11.Controls.Add(this.c5);
            this.panel11.Controls.Add(this.b5);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 267);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(207, 46);
            this.panel11.TabIndex = 12;
            // 
            // la05
            // 
            this.la05.AutoSize = true;
            this.la05.BackColor = System.Drawing.Color.Transparent;
            this.la05.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la05.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la05.Location = new System.Drawing.Point(24, 15);
            this.la05.Name = "la05";
            this.la05.Size = new System.Drawing.Size(38, 16);
            this.la05.TabIndex = 5;
            this.la05.Text = "EOS";
            this.la05.Click += new System.EventHandler(this.la05_Click);
            // 
            // c5
            // 
            this.c5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c5.Dock = System.Windows.Forms.DockStyle.Left;
            this.c5.Location = new System.Drawing.Point(0, 0);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(20, 46);
            this.c5.TabIndex = 0;
            this.c5.TabStop = false;
            this.c5.Visible = false;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Transparent;
            this.b5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b5.BackgroundImage")));
            this.b5.Dock = System.Windows.Forms.DockStyle.Right;
            this.b5.Location = new System.Drawing.Point(0, 0);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(207, 46);
            this.b5.TabIndex = 1;
            this.b5.TabStop = false;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.la06);
            this.panel12.Controls.Add(this.c6);
            this.panel12.Controls.Add(this.b6);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 313);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(207, 46);
            this.panel12.TabIndex = 13;
            // 
            // la06
            // 
            this.la06.AutoSize = true;
            this.la06.BackColor = System.Drawing.Color.Transparent;
            this.la06.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la06.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.la06.Location = new System.Drawing.Point(24, 15);
            this.la06.Name = "la06";
            this.la06.Size = new System.Drawing.Size(93, 16);
            this.la06.TabIndex = 6;
            this.la06.Text = "Bitcoin Cash";
            this.la06.Click += new System.EventHandler(this.la06_Click);
            // 
            // c6
            // 
            this.c6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c6.Dock = System.Windows.Forms.DockStyle.Left;
            this.c6.Location = new System.Drawing.Point(0, 0);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(20, 46);
            this.c6.TabIndex = 0;
            this.c6.TabStop = false;
            this.c6.Visible = false;
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Transparent;
            this.b6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b6.BackgroundImage")));
            this.b6.Dock = System.Windows.Forms.DockStyle.Right;
            this.b6.Location = new System.Drawing.Point(0, 0);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(207, 46);
            this.b6.TabIndex = 1;
            this.b6.TabStop = false;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.la07);
            this.panel13.Controls.Add(this.label7);
            this.panel13.Controls.Add(this.c7);
            this.panel13.Controls.Add(this.b7);
            this.panel13.Location = new System.Drawing.Point(0, 426);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(207, 46);
            this.panel13.TabIndex = 14;
            // 
            // la07
            // 
            this.la07.AutoSize = true;
            this.la07.BackColor = System.Drawing.Color.Transparent;
            this.la07.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la07.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.la07.Location = new System.Drawing.Point(24, 15);
            this.la07.Name = "la07";
            this.la07.Size = new System.Drawing.Size(98, 16);
            this.la07.TabIndex = 7;
            this.la07.Text = "Small Window";
            this.la07.Click += new System.EventHandler(this.la07_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(23, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 7;
            // 
            // c7
            // 
            this.c7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c7.Dock = System.Windows.Forms.DockStyle.Left;
            this.c7.Location = new System.Drawing.Point(0, 0);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(20, 46);
            this.c7.TabIndex = 0;
            this.c7.TabStop = false;
            this.c7.Visible = false;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.Transparent;
            this.b7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b7.BackgroundImage")));
            this.b7.Location = new System.Drawing.Point(0, 0);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(207, 46);
            this.b7.TabIndex = 1;
            this.b7.TabStop = false;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.metroPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.metroPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroPanel1.BackgroundImage")));
            this.metroPanel1.Controls.Add(this.panel45);
            this.metroPanel1.Controls.Add(this.panel44);
            this.metroPanel1.Controls.Add(this.panel39);
            this.metroPanel1.Controls.Add(this.panel13);
            this.metroPanel1.Controls.Add(this.panel12);
            this.metroPanel1.Controls.Add(this.panel11);
            this.metroPanel1.Controls.Add(this.panel4);
            this.metroPanel1.Controls.Add(this.panel3);
            this.metroPanel1.Controls.Add(this.panel2);
            this.metroPanel1.Controls.Add(this.panel1);
            this.metroPanel1.Controls.Add(this.metroPanel2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(-1, -3);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(207, 604);
            this.metroPanel1.TabIndex = 6;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // la08
            // 
            this.la08.AutoSize = true;
            this.la08.BackColor = System.Drawing.Color.Transparent;
            this.la08.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la08.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.la08.Location = new System.Drawing.Point(25, 14);
            this.la08.Name = "la08";
            this.la08.Size = new System.Drawing.Size(123, 16);
            this.la08.TabIndex = 17;
            this.la08.Text = "Detail View Mode";
            this.la08.Click += new System.EventHandler(this.la08_Click);
            // 
            // c9
            // 
            this.c9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c9.Dock = System.Windows.Forms.DockStyle.Left;
            this.c9.Location = new System.Drawing.Point(0, 0);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(20, 46);
            this.c9.TabIndex = 16;
            this.c9.TabStop = false;
            this.c9.Visible = false;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.Transparent;
            this.b9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b9.BackgroundImage")));
            this.b9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.b9.Location = new System.Drawing.Point(0, 0);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(207, 46);
            this.b9.TabIndex = 15;
            this.b9.TabStop = false;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // la09
            // 
            this.la09.AutoSize = true;
            this.la09.BackColor = System.Drawing.Color.Transparent;
            this.la09.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la09.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.la09.Location = new System.Drawing.Point(25, 16);
            this.la09.Name = "la09";
            this.la09.Size = new System.Drawing.Size(110, 16);
            this.la09.TabIndex = 9;
            this.la09.Text = "Setting Window";
            this.la09.Click += new System.EventHandler(this.la09_Click);
            // 
            // c8
            // 
            this.c8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c8.Dock = System.Windows.Forms.DockStyle.Left;
            this.c8.Location = new System.Drawing.Point(0, 0);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(20, 46);
            this.c8.TabIndex = 8;
            this.c8.TabStop = false;
            this.c8.Visible = false;
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.Transparent;
            this.b8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b8.BackgroundImage")));
            this.b8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.b8.Location = new System.Drawing.Point(0, 0);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(207, 46);
            this.b8.TabIndex = 8;
            this.b8.TabStop = false;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // Front_page
            // 
            this.Front_page.Controls.Add(this.label12);
            this.Front_page.Location = new System.Drawing.Point(219, 51);
            this.Front_page.Name = "Front_page";
            this.Front_page.Size = new System.Drawing.Size(902, 537);
            this.Front_page.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(369, 250);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 33);
            this.label12.TabIndex = 64;
            this.label12.Text = "X Monitor II";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Main01
            // 
            this.Main01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Main01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Main01.Location = new System.Drawing.Point(219, 51);
            this.Main01.Name = "Main01";
            this.Main01.Size = new System.Drawing.Size(902, 537);
            this.Main01.TabIndex = 0;
            this.Main01.Paint += new System.Windows.Forms.PaintEventHandler(this.Main01_Paint);
            // 
            // panel38
            // 
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.chart1);
            this.panel38.Location = new System.Drawing.Point(14, 288);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(873, 237);
            this.panel38.TabIndex = 59;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.c8);
            this.panel39.Controls.Add(this.la09);
            this.panel39.Controls.Add(this.b8);
            this.panel39.Location = new System.Drawing.Point(0, 516);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(207, 46);
            this.panel39.TabIndex = 15;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.la08);
            this.panel44.Controls.Add(this.c9);
            this.panel44.Controls.Add(this.b9);
            this.panel44.Location = new System.Drawing.Point(0, 471);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(207, 46);
            this.panel44.TabIndex = 15;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.label24);
            this.panel45.Controls.Add(this.pictureBox1);
            this.panel45.Controls.Add(this.pictureBox2);
            this.panel45.Location = new System.Drawing.Point(0, 561);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(207, 38);
            this.panel45.TabIndex = 15;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Enabled = false;
            this.label24.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(23, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 16);
            this.label24.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 38);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(207, 38);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.Transparent;
            this.chart1.BorderlineColor = System.Drawing.Color.Transparent;
            this.chart1.BorderSkin.BackColor = System.Drawing.Color.Transparent;
            this.chart1.BorderSkin.BorderColor = System.Drawing.Color.DimGray;
            this.chart1.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisX.TitleForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX2.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX2.MajorGrid.Enabled = false;
            chartArea1.AxisX2.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX2.TitleForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY.MajorTickMark.Enabled = false;
            chartArea1.AxisY.TitleForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY2.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY2.MajorGrid.Enabled = false;
            chartArea1.AxisY2.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY2.MajorTickMark.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisY2.TitleForeColor = System.Drawing.Color.Transparent;
            chartArea1.BackColor = System.Drawing.Color.Transparent;
            chartArea1.BorderColor = System.Drawing.Color.Transparent;
            chartArea1.InnerPlotPosition.Auto = false;
            chartArea1.InnerPlotPosition.Height = 82.18086F;
            chartArea1.InnerPlotPosition.Width = 93.28992F;
            chartArea1.InnerPlotPosition.X = 3.79305F;
            chartArea1.InnerPlotPosition.Y = 4.46808F;
            chartArea1.Name = "ChartArea1";
            chartArea1.ShadowColor = System.Drawing.Color.Transparent;
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.BorderWidth = 0;
            legend1.ForeColor = System.Drawing.Color.Transparent;
            legend1.HeaderSeparatorColor = System.Drawing.Color.White;
            legend1.ItemColumnSeparatorColor = System.Drawing.Color.White;
            legend1.MaximumAutoSize = 0F;
            legend1.Name = "Legend1";
            legend1.TitleForeColor = System.Drawing.Color.White;
            legend1.TitleSeparatorColor = System.Drawing.Color.White;
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chart1.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))))};
            series1.BorderColor = System.Drawing.Color.Transparent;
            series1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            series1.LabelBackColor = System.Drawing.Color.Transparent;
            series1.LabelForeColor = System.Drawing.Color.Transparent;
            series1.Legend = "Legend1";
            series1.MarkerBorderColor = System.Drawing.Color.Transparent;
            series1.MarkerColor = System.Drawing.Color.Transparent;
            series1.Name = "DateTime";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series1.ShadowColor = System.Drawing.Color.Transparent;
            series1.SmartLabelStyle.CalloutLineColor = System.Drawing.Color.White;
            series1.YValuesPerPoint = 4;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(871, 235);
            this.chart1.TabIndex = 0;
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // ddlTime
            // 
            this.ddlTime.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ddlTime.FormattingEnabled = true;
            this.ddlTime.Location = new System.Drawing.Point(219, 25);
            this.ddlTime.Name = "ddlTime";
            this.ddlTime.Size = new System.Drawing.Size(121, 20);
            this.ddlTime.TabIndex = 10;
            this.ddlTime.Visible = false;
            // 
            // ddlCoin
            // 
            this.ddlCoin.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ddlCoin.FormattingEnabled = true;
            this.ddlCoin.Location = new System.Drawing.Point(346, 25);
            this.ddlCoin.Name = "ddlCoin";
            this.ddlCoin.Size = new System.Drawing.Size(121, 20);
            this.ddlCoin.TabIndex = 11;
            this.ddlCoin.Visible = false;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 600);
            this.Controls.Add(this.ddlCoin);
            this.Controls.Add(this.ddlTime);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.price_panel);
            this.Controls.Add(this.Main01);
            this.Controls.Add(this.Front_page);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1135, 600);
            this.MinimumSize = new System.Drawing.Size(1135, 600);
            this.Name = "MainWindow";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Text = "WatchDocks Beta";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.price_panel.ResumeLayout(false);
            this.price_panel.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b4)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b5)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b6)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b7)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b8)).EndInit();
            this.Front_page.ResumeLayout(false);
            this.Front_page.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox n5;
        private System.Windows.Forms.TextBox n4;
        private System.Windows.Forms.TextBox n3;
        private System.Windows.Forms.TextBox n2;
        private System.Windows.Forms.TextBox n1;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox n9;
        private System.Windows.Forms.TextBox n8;
        private System.Windows.Forms.TextBox n7;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label la01;
        private System.Windows.Forms.PictureBox c1;
        private System.Windows.Forms.PictureBox b1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label la02;
        private System.Windows.Forms.PictureBox c2;
        private System.Windows.Forms.PictureBox b2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label la03;
        private System.Windows.Forms.PictureBox c3;
        private System.Windows.Forms.PictureBox b3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox c4;
        private System.Windows.Forms.PictureBox b4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.PictureBox c5;
        private System.Windows.Forms.PictureBox b5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox c6;
        private System.Windows.Forms.PictureBox b6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox c7;
        private System.Windows.Forms.PictureBox b7;
        private System.Windows.Forms.Label la04;
        private System.Windows.Forms.Label la05;
        private System.Windows.Forms.Label la06;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label la07;
        private System.Windows.Forms.ToolStripMenuItem openSmallScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openMainScreenToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label la09;
        private System.Windows.Forms.PictureBox c8;
        private System.Windows.Forms.PictureBox b8;
        private System.Windows.Forms.Label la08;
        private System.Windows.Forms.PictureBox c9;
        private System.Windows.Forms.PictureBox b9;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.TextBox textBox9;
        public System.Windows.Forms.Panel price_panel;
        public MetroFramework.Controls.MetroPanel metroPanel1;
        public System.Windows.Forms.Panel Front_page;
        public System.Windows.Forms.Panel Main01;
        public System.Windows.Forms.Label t1;
        public System.Windows.Forms.Label t2;
        public System.Windows.Forms.Label t3;
        public System.Windows.Forms.Label t4;
        public System.Windows.Forms.Label t5;
        public System.Windows.Forms.Label t9;
        public System.Windows.Forms.Label t8;
        public System.Windows.Forms.Label t7;
        public System.Windows.Forms.Label Set6;
        public System.Windows.Forms.Label Set5;
        public System.Windows.Forms.Label Set4;
        public System.Windows.Forms.Label Set3;
        public System.Windows.Forms.Label Set2;
        public System.Windows.Forms.Label Set1;
        public System.Windows.Forms.Label Set12;
        public System.Windows.Forms.Label Set11;
        public System.Windows.Forms.Label Set10;
        public System.Windows.Forms.Label Set9;
        public System.Windows.Forms.Label Set8;
        public System.Windows.Forms.Label Set7;
        private System.Windows.Forms.ToolStripMenuItem detailViewToolStripMenuItem;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox n7_2;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.Label t7_2;
        private System.Windows.Forms.Panel panel23;
        public System.Windows.Forms.Label usd07;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel24;
        public System.Windows.Forms.Label usd06;
        private System.Windows.Forms.Panel panel25;
        public System.Windows.Forms.Label usd01;
        private System.Windows.Forms.Panel panel26;
        public System.Windows.Forms.Label usd02;
        private System.Windows.Forms.Panel panel27;
        public System.Windows.Forms.Label usd03;
        private System.Windows.Forms.Panel panel28;
        public System.Windows.Forms.Label usd04;
        private System.Windows.Forms.Panel panel29;
        public System.Windows.Forms.Label usd05;
        private System.Windows.Forms.Panel panel30;
        public System.Windows.Forms.Label v2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel31;
        public System.Windows.Forms.Label v1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ComboBox ddlTime;
        private System.Windows.Forms.ComboBox ddlCoin;
    }
}

